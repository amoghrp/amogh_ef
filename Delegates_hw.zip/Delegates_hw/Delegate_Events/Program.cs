﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate_Events
{
    internal class Program
    {
        
        static void Main(string[] args)
        {
            Form f = new Form();
            
            f.b = new Button();
            f.SubscribeToButtonClick();
            f.b.Click();
            

        }
    }
    public delegate void ButtonClicked();
    public class Button
    {
        public static event ButtonClicked bc;
        public void Click() 
        {
            Console.WriteLine("click method called inside button class");
            // invokes a delegate
            if (bc != null)
            {
                bc();
            }

        }
    }
    public class Form
    {
        public Button b;
        public  void SubscribeToButtonClick()
        {
            
            Button.bc += ()=> Console.WriteLine("anonymous method called");
        }
    }
}
