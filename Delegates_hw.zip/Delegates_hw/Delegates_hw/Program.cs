﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates_hw
{
    public delegate string StringModifier(string x);
    internal class Program
    {
        static void Main(string[] args)
        {
            StringModifier sm = UpperCase;
       
            string upperCaseString = sm("amogh");
            Console.WriteLine(upperCaseString);
            sm += LowerCase;
            sm += Reverse;

            string res = sm("AmoghRPatil");
            Console.WriteLine(res); // till here it only creates reverse one

            // now lets do chaining
            StringModifier sm2 = UpperCase;
            sm2 += Reverse;
            string output = sm2("abc");
            Console.WriteLine(output);

        }
        public static string UpperCase(string s)
        {
            
            return s.ToUpper();
        }
        public static string LowerCase(string s) {  return s.ToLower(); }

        public static string Reverse(string s)
        {
            

            return new string(s.Reverse().ToArray());
        }
    }
}
