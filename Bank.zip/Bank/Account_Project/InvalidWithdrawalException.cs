﻿using System;
using System.Runtime.Serialization;

namespace Account_Project
{
    [Serializable]
    public class InvalidWithdrawalException : Exception
    {
        public InvalidWithdrawalException()
        {
        }

        public InvalidWithdrawalException(string message) : base(message)
        {
        }

        public InvalidWithdrawalException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected InvalidWithdrawalException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}