﻿using Account_Project;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Account_Mgr
{
    public class AccountManager
    {
        public List<Account> accounts;

        public AccountManager()
        {
            accounts = new List<Account>();
        }

        public AccountManager(List<Account> accounts)
        {
            this.accounts = accounts;
        }


        public void AddAccount(Account account)
        {
            accounts.Add(account);
        }

       /* public Account GetAccountByNumber(int accountNumber)
        {
            return accounts.Find(acc => acc.AccNo == accountNumber);
        }*/

        public void OpenAccount(string accountHolderName,int pin)
        {
            if (accounts.Any(acc => acc.Name == accountHolderName))
            {
                throw new AccountAlreadyExistsException("An account with this name holder already exists.");
            }

            // Generate a new account number (replace this with your actual logic)
            int newAccountNumber = GenerateNewAccountNumber();

            // Create a new account and add it to the list
            Account newAccount = new Account(newAccountNumber, accountHolderName, 1000, pin);
            accounts.Add(newAccount);

            // Set the opening date
            newAccount.OpeningDate = DateTime.Now;
        }

        public void CloseAccount(string accountHolderName)
        {
            Account accountToClose = GetAccount(accountHolderName);

            if (accountToClose == null)
            {
                throw new AccountNotFoundException("Account not found.");
            }

            if (accountToClose.ClosingDate.HasValue)
            {
                throw new AccountAlreadyClosedException("Account is already closed.");
            }

            // Set the closing date
            accountToClose.ClosingDate = DateTime.Now;
        }

        public Account GetAccount(string accountHolderName)
        {
            Account account = accounts.Find(acc => acc.Name == accountHolderName);

            if (account == null)
            {
                throw new AccountNotFoundException("Account not found.");
            }

            return account;
        }

        public void Withdraw(string accountHolderName, int pin, decimal amount)
        {
            Account account = GetAccount(accountHolderName);

            // Call the account's withdraw method
            account.Withdraw(pin, amount);
        }

        public void Transfer(string senderName, string receiverName, int senderPin, decimal amount)
        {
            Account senderAccount = GetAccount(senderName);
            Account receiverAccount = GetAccount(receiverName);

            // Call the account's transfer method
            senderAccount.Transfer(receiverAccount, senderPin, amount);
        }

        public void Deposit(string accountHolderName, decimal amount)
        {
            Account account = GetAccount(accountHolderName);

            // Call the account's deposit method
            account.Deposit(amount);
        }

        private int GenerateNewAccountNumber()
        {
            // Replace this with your actual logic to generate a new unique account number
            return accounts.Count + 1;
        }
    }

}
