﻿using System;
using System.Runtime.Serialization;

namespace Account_Mgr
{
    [Serializable]
   public class AccountAlreadyClosedException : Exception
    {
        public AccountAlreadyClosedException()
        {
        }

        public AccountAlreadyClosedException(string message) : base(message)
        {
        }

        public AccountAlreadyClosedException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected AccountAlreadyClosedException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}