﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Account_ns
{
  

    public class Account
    {
        // Properties
        public int AccNo { get;  set; }
        public string Name { get; set; }
        public decimal Balance { get;  set; }
        public int PinNumber { get;  set; }
        public bool IsActive { get; set; }
        public DateTime OpeningDate { get; set; }
        public DateTime? ClosingDate { get; set; }

        public Account(int accNo, string name, decimal initialBalance, int pinNumber)
        {
            AccNo = accNo;
            Name = name;
            Balance = initialBalance;
            PinNumber = pinNumber;
            IsActive = true;
            OpeningDate = DateTime.Now;
            ClosingDate = null;
        }

        public void Deposit(decimal amount)
        {
            if (!IsActive)
            {
                throw new AccountClosedException("Account is closed. Cannot withdraw funds.");
            }

            Balance += amount;
        }

        public void Withdraw(int enteredPin, decimal amount)
        {
            if (!IsActive)
            {
                throw new AccountClosedException("Account is closed. Cannot withdraw funds.");
            }

            if (PinNumber != enteredPin)
            {
                throw new InvalidWithdrawalException("Incorrect PIN. Withdrawal failed.");
            }

            if (Balance < amount)
            {
                throw new InvalidWithdrawalException("Insufficient funds. Withdrawal failed.");
            }

            Balance -= amount;
        }

        public void Transfer(Account destinationAccount, int sourcePin, decimal amount)
        {
            if (!IsActive || !destinationAccount.IsActive)
            {
                throw new AccountClosedException("Account is closed. Cannot transfer funds.");
            }

            if (PinNumber != sourcePin)
            {
                throw new InvalidTransferException("Incorrect PIN. Transfer failed.");
            }

            if (Balance < amount)
            {
                throw new InvalidTransferException("Insufficient funds. Transfer failed.");
            }

            Balance -= amount;

            destinationAccount.Deposit(amount);
        }

        public void MakeInactive()
        {
            this.IsActive = false;
        }

      
    }

   

}
