﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTSProgram11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /* 
             *11. Write a pseudocode to display a number in words. 
             *Ex. 270176 
             *Output: Two Seven Zero One Seven Six 
            */
            int n;
            Console.WriteLine("enter number");
            n = Convert.ToInt32(Console.ReadLine());
            string ans="";
            while (n > 0)
            {
                int r = n % 10;
                ans =  Convert.ToString(r) + ans;
                n /= 10;
            }
            for(int i = 0; i < ans.Length; i++)
            {
                switch(ans[i])
                {
                    case '0': Console.Write("Zero ");
                        break;
                    case '1': Console.Write("One ");
                        break;
                    case '2': Console.Write("Two ");
                        break;
                    case '3': Console.Write("Three ");
                        break;
                    case '4': Console.Write("Four ");
                        break;
                    case '5': Console.Write("Five ");
                        break;
                    case '6': Console.Write("Six ");
                        break;
                    case '7': Console.Write("Seven ");
                        break;
                    case '8': Console.Write("Eight ");
                        break;
                    case '9': Console.Write("Nine ");
                        break;
                    default: Console.Write("invalid input");
                        break;
                }
            }
        }
    }
}
