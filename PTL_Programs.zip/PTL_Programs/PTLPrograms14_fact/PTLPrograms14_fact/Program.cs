﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms14_fact
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*14. Write a pseudocode to find the factorial of a given number. 0! is always 1. 
            Factorial of a negative number is not possible. */
            int n;
            Console.WriteLine("enter a number");
            n = Convert.ToInt32(Console.ReadLine());    
            Console.WriteLine($"factorial of {n} = {fact(n)}");

        }
        public static int fact(int n)
        {
            if (n < 0) { Console.WriteLine("factorial of negative number is not possible");
                Environment.Exit(0);
            }
            if(n==0 || n == 1)
            {
                return 1;
            }
            return fact(n-1)*n;

        }
    }
}
