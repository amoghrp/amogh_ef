﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms27
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*27. Write a pseudocode to store N elements in an array of integer. Display the 
elements. Sort the elements. Accept a number to be searched. Display whether 
the number is found or not in the array using BINARY SEARCH. */
            Console.Write("Enter size of array ");
            int n = Convert.ToInt32(Console.ReadLine());

            int[] arr = new int[n];

            
            Console.WriteLine("Enter the elements of the array:");
            for (int i = 0; i < n; i++)
            {
                
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }

            
            

            
            Array.Sort(arr);

            
            Console.WriteLine("\n\nThe sorted array is:");
            for (int i = 0; i < n; i++)
            {
                Console.Write(arr[i] + " ");
            }

            
            Console.Write("\n\nEnter the number to be searched: ");
            int searchNumber = Convert.ToInt32(Console.ReadLine());

            
            bool found = BinarySearch(arr, searchNumber);

           
            if (found)
            {
                Console.WriteLine($"{searchNumber} is found in the array.");
            }
            else
            {
                Console.WriteLine($"{searchNumber} is not found in the array.");
            }
        }
        static bool BinarySearch(int[] arr, int searchNumber)
        {
            int left = 0;
            int right = arr.Length - 1;

            while (left <= right)
            {
                int mid = left + (right - left) / 2;

                if (arr[mid] == searchNumber)
                {
                    return true;
                }

                if (arr[mid] < searchNumber)
                {
                    left = mid + 1;
                }
                else
                {
                    right = mid - 1;
                }
            }

            return false;
        }
    }
}
