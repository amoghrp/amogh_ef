﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLProgram12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter a number ");

            int n = Convert.ToInt32(Console.ReadLine());
            Program p = new Program();
            p.series1(n);
            Console.WriteLine();
            p.series2(n);
            Console.WriteLine();
            p.series3(n);
            Console.WriteLine();
            p.series4(n);
            Console.WriteLine();
            p.series5(n);
            Console.WriteLine();
            p.series6(n);
            

        }
        void series1(int n) {
            for(int i = 2; i <= n; i += 2)
            {
                Console.Write(Math.Pow(i,2) +" ");
            }
        }
        void series2(int n) { 
            for(int i = 1; i <= n; i++)
            {
                if (i % 2!=0){
                    Console.Write(i + " ");
                }
                else
                {
                    Console.Write(-i + " ");
                }
            }
        }
        void series3(int n){
            for(int i = 1; i <= n; i++)
            {
                Console.Write(Math.Pow(i,i) + " ");
            }
        }
        void series4(int n) {
            int t1 = 1, t2 = 4, t3 = 7;
            Console.Write(t1+" "+t2+" "+t3 + " ");
            while (n>0)
            {
                n--;
                int t4 = t1 + t2 + t3;
                Console.Write(t4+" ");
                t1 = t2;
                t2 = t3;
                t3 = t4;

            }

        }
        void series5(int n){
            int cnt = 0;
            for (int i = 1; i <= n; i++)
            {
                if (cnt == 3) { cnt = 0; continue; }
                Console.Write(Math.Pow(i,2) + " ");
                cnt++;
            }
        }
        void series6(int n) {
            int i = 1;
            Console.Write(i+" ");
            int mul_val = 1;
            int cnt = 0;
            while (n>0)
            {
                n--;
                
                if(cnt==2) { cnt = 0;
                    mul_val++;
                    continue; 
                }
                cnt++;
                i = i + 4 * mul_val;
                Console.Write(i+ " ");
                mul_val++;   
                
            }
        }
    }
}
