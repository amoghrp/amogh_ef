﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms17
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
        17. Write a pseudocode to display the 1st , 2nd , and 4th multiple of 7 which gives the 
        remainder 1 when divided by 2,3,4,5 and 6  
            */
            int[] multiples = new int[4];
            int num = 7;
            int x = 1;
            int i = 0;
            for(; ; )
            {
                int multiple = num * x;
                if (multiple % 2==1 && multiple % 3 == 1 && multiple % 4 == 1 && multiple % 5 == 1 && multiple % 6 == 1)
                {
                    multiples[i] = multiple;
                    i++;
                    if (i == 4) break;
                }
                x++;
            }
            
            Console.WriteLine($"1st = {multiples[0]} second = {multiples[1]} fourth = {multiples[3]}");

        }
    }
}
