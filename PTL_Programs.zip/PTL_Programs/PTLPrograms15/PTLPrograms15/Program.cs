﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms15
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
             15. Write a pseudocode to accept a decimal number. Display it in the binary form. 

             */
            int n;
            Console.WriteLine("enter a number");
            n = Convert.ToInt32(Console.ReadLine());
            string ans = "";
            while (n > 0)
            {
                int r = n % 2;
                ans = r + ans;
                //Console.Write(ans + " r= " + r);
                n /= 2;
            }
            Console.WriteLine(ans);

        }
    }
}
