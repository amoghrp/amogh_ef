﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PLTPrograms24
{
    internal class Program
    {
        static void Main(string[] args)
        {
            pattern4(6);
        }
        public static void pattern1(int n) {
            for(int i = 0; i < n; i++)
            {
                for(int j = 0; j <= i; j++)
                {
                    Console.Write(j+1  + " ");
                }
                Console.WriteLine();
            }

        }
        public static void pattern2(int n)
        {
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j <= i; j++)
                {
                    Console.Write(i + 1 + " ");
                }
                Console.WriteLine();
            }

        }
        public static void pattern3(int n)
        {
            int x = 0;
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j <= i; j++)
                {
                    Console.Write(x + 1 + " ");
                    x++;
                }
                Console.WriteLine();
            }

        }
        public static void pattern4(int n)
        {
            
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j <= i; j++)
                {
                    Console.Write(get_next_fibo()+" ");
                   
                }
                Console.WriteLine();
            }

        }
        static int x = 1, y = 1, call=0;
        public static int get_next_fibo()
        {
            if (call == 0) { call++; return 1; };
            if (call == 1) { call++; return 1; };

            int z = x + y;
            x = y;
            y = z;
            return z; 
        }
    }
}
