﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms25
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //pattern1(6);
            pattern3(6);
            pattern4(6);
        }
        public static void pattern1(int n)
        {
            int eo = 0;
            int a = 1;
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j <= i; j++)
                {
                    if (eo % 2 == 0)
                    {
                        Console.Write(Math.Pow(a,2)+" ");
                    }
                    else
                    {
                        Console.Write("-"+(Math.Pow(a,2))+" ");
                    }
                    a++;
                    eo++;
                }
                Console.WriteLine();
            }

        }
        public static void pattern2(int n)
        {
            int x = 0;
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j <= i; j++)
                {
                    Console.Write(fact(x)+" ");
                    x++;
                }
                Console.WriteLine();
            }

        }
        public static int fact(int n)
        {
            if (n == 0 || n == 1) return 1;
             return fact(n - 1) * n;
        }
        public static void pattern3(int n)
        {
            for(int i = 0; i < n; i++)
            {
                int j = 0;
                for( j=0;j< n - i - 1; j++)
                {
                    Console.Write(" ");
                }
                for(; j < n; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
        }
        public static void pattern4(int n)
        {
            int stars = 1;
            for (int i = 0; i < n; i++)
            {
                int j = 0;
                for (j = 0; j < n - i - 1; j++)
                {
                    Console.Write(" ");
                }
                for (j = 0; j < stars; j++)
                {
                    Console.Write("*");
                }
                stars += 2;
                Console.WriteLine();
            }

        }
    }
}
