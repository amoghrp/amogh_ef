﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms21
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
             21. Write a pseudocode to display the reverse of a string. 
             */
            Console.WriteLine("enter string");
            string s = Console.ReadLine();
            for(int i=s.Length-1; i>=0; i--)
            {
                Console.Write(s[i] + " ");
            }
            Console.WriteLine();
        }
    }
}
