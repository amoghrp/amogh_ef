﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms28
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
             * 28. Write a pseudocode to store elements into a M * N matrix of integer. Display the 
                matrix and its transpose. 
            */
            Console.Write("Enter M ");
            int M = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter N");
            int N = Convert.ToInt32(Console.ReadLine());

            int[,] matrix = new int[M, N];

           
            Console.WriteLine("Enter  elements");
            for (int i = 0; i < M; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    
                    matrix[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine("\nThe matrix is:");
            for (int i = 0; i < M; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    Console.Write(matrix[i, j] + " ");
                }
                Console.WriteLine();
            }

            
            Console.WriteLine("\nThe transpose of the matrix is:");
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < M; j++)
                {
                    Console.Write(matrix[j, i] + " ");
                }
                Console.WriteLine();
            }
        }
    }
}
