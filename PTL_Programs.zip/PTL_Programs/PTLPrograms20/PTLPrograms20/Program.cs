﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms20
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
            20. Write a pseudocode to find Xn (x to the power of n). 
            Accept X and n. Display the
            result. 
            */
            int x, n;
            Console.WriteLine("enter x and n");
            x = Convert.ToInt32(Console.ReadLine());
            n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(Math.Pow(x,n));
        }
    }
}
