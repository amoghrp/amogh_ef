﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // program to accept a number and display even or odd
            int a = 0;
            Console.WriteLine("enter a number ");
            a = Convert.ToInt32(Console.ReadLine());
            if (a % 2 == 0)
            {
                Console.WriteLine($"the number {a} is even");
            }
            else
            {
                Console.WriteLine($"the number {a} is odd");
            }

        }
    }
}
