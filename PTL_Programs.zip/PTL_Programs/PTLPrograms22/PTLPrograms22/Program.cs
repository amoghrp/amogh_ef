﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms22
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //22. Write a pseudocode to check if the string is a palindrome
            Console.WriteLine("enter string ");
            string s = Console.ReadLine();

            Console.WriteLine(isPalindrome(s));
            Console.WriteLine();
        }
        public static bool isPalindrome(string s)
        {
            string rev = "";
            for(int i=0;i<s.Length; i++)
            {
                rev = s[i] + rev;
            }
            if(rev== s) return true;
            return false;
        }
    }
}
