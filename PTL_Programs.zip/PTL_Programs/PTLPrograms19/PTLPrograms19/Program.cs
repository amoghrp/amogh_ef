﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms19
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
             19. Write the pseudocodes to generate the following series. 
            In all the following cases, accept N: 
            1, -2, 6, -15, 31, -56, … N 
            1, 1, 2, 3, 5, 8, 13, … N 
            1, -2, 4, -6, 7,-10, 10,-14… N 
            1, 5, 8, 14, 27, 49, … N 
             */
            series1(9);
            series2(9);
            series3(9);
            series4(19);

        }
        public static void series1(int n)
        {
            int a = 1;
            int x = 0;
            for(int i = 0; i < n; i++)
            {

                if (i % 2 == 0)
                {
                    Console.Write($"{a + (int)Math.Pow(x, 2)}  ");
                }
                else
                {
                    Console.Write($"{ -(a + (int)Math.Pow(x, 2)) }  ");
                }
                a = a + (int)Math.Pow(x,2);
                x++;
            }
        }
        public static void series2(int n)
        {
            int a = 0, b = 1;
            Console.Write($"{a}, {b} ");
            for (int i = 2; i <= n; i++)
            {
                int c = b + a;
                Console.Write($"{c} ");
                a = b;
                b = c;
            }
        }
        public static void series3(int n)
        {
            int a = 1, b = 2;
            for (int i = 0; i < n; i++)
            {
                
                if(i% 2 == 0)
                {
                    Console.Write($"{a} ");
                    a += 3;
                }
                else
                {
                    Console.Write($"{-b} ");
                    b += 4;
                }
            }
        }
        public static void series4(int n)
        {
            int a = 1, b = 5, c = 8;
            Console.Write($"{a} {b} {c} ");
            for(int i = 3; i < n; i++)
            {
                int x = a + b + c;
                Console.Write($"{x} ");
                a = b;
                b = c;
                c = x;
            }
        }
    }
}
