﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLProgram_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double principle, rateOfInterest, time;
            Console.WriteLine("enter principle:");
            string inp = Console.ReadLine(); 
            principle = Convert.ToDouble(inp);
            Console.WriteLine("enter rate of interest");
            inp = Console.ReadLine();
            rateOfInterest = Convert.ToDouble(inp);
            Console.WriteLine("enter time");
            inp = Console.ReadLine();
            time = Convert.ToDouble(inp);

            Program p = new Program();
            double ans = p.CalculateSI(principle,rateOfInterest,time);
            Console.WriteLine($"simple interest is = {ans}");


        }
        double CalculateSI(double p,double r, double t)
        {
            double SI = (p * t * r) / 100;
            return SI;
        }
    }
}
