﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms18
{
    using System;

    class Item
    {
        public string ItemCode { get; set; }
        public string Description { get; set; }
        public int Quantity { get; set; }
        public double Price { get; set; }

        public double CalculateTotal()
        {
            return Quantity * Price;
        }
    }

    internal class Program
            {
                static void Main(string[] args)
                {
                    double grandTotal = 0;

                    do
                    {
                        Item item = GetItemDetails();
                        double total = item.CalculateTotal();
                        grandTotal += total;

                        Console.WriteLine($"Total for the item: Rs. {total}");

                        Console.Write("wanna .. buy another item? (y/n): ");
                    } while (Console.ReadLine().ToLower() == "y");

                    if (grandTotal > 10000)
                    {
                        grandTotal *= 0.9; // Apply 10% discount
                    }
                    else if (grandTotal < 1000)
                    {
                        Console.Write("wanna pay by card? (y/n): ");
                        if (Console.ReadLine().ToLower() == "y")
                        {
                            grandTotal *= 1.025; // Apply 2.5% surcharge
                        }
                    }

                    Console.WriteLine($"Grand Total: Rs. {grandTotal}");
                }

                static Item GetItemDetails()
                {
                    Console.Write("item Ccode ");
                    string code = Console.ReadLine();

                    Console.Write("Description: ");
                    string description = Console.ReadLine();

                    Console.Write("Quantity: ");
                    int quantity = Convert.ToInt32(Console.ReadLine());

                    Console.Write("Price per Item: ");
                    double price = Convert.ToDouble(Console.ReadLine());

                    return new Item { ItemCode = code, Description = description, Quantity = quantity, Price = price };
                }
    }
}
