﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms30
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write(" size   ");
            int N = Convert.ToInt32(Console.ReadLine());

            int[,] matrix = new int[N, N];

            Console.WriteLine("Enter the elements of the matrix:");
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    matrix[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    Console.Write(matrix[i, j] + " ");
                }
                Console.WriteLine();
            }

            bool isSymmetric = true;
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < i; j++)
                {
                    if (matrix[i, j] != matrix[j, i])
                    {
                        isSymmetric = false;
                        break;
                    }
                }
                if (!isSymmetric)
                {
                    break;
                }
            }

            if (isSymmetric)
            {
                Console.WriteLine("\nsymmetric ");
            }
            else
            {
                Console.WriteLine("\n not a symmetric .");
            }
        }
    }
}
