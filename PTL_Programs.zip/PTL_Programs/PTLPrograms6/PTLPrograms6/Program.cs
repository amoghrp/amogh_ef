﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //6. Write a pseudocode to find the largest and second largest of 3 numbers  
            function();

        }
        public static void function()
        {
            Console.WriteLine("enter 3 numbers");
            Console.WriteLine("enter number 1");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter number 2");
            int b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter number 3");
            int c = Convert.ToInt32(Console.ReadLine());
            int fl = Math.Max(a, Math.Max(b, c));
            int sl;
            if (fl == a)
            {
                sl = Math.Max(b, c);
            }
            else if (fl == b)
            {
                sl = Math.Max(c, a);
            }
            else
            {
                sl = Math.Max(a, b);
            }
            Console.WriteLine($"first largest is {fl}\n    and second largest is {sl}");
        }
    }
}
