﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
7. Write a pseudocode to accept name, empId, basic, special allowances, percentage of 
bonus and monthly tax saving investments. The gross monthly salary is basic + special 
allowances. Compute the annual salary. The gross annual salary also includes the bonus. 
Compute the annual net salary, by deducting taxes as suggested. 

Income upto 1 lac – exempted 
Income from 1 to 1.5 lac – 20% 
Income from 1.5 lac onwards – 30% 

However if there is any tax saving investment, then there is further exemption of upto 1 
lac annually. This would mean that by having tax saving investments of about 1 lac, an 
income of 2 lacs is non-taxable. Display the annual gross, annual net and tax payable.

             */
            Employee employee = new Employee();
            Console.WriteLine("enter emplpoyee details");
            Console.WriteLine( "name:");
            employee.name= Console.ReadLine();
            Console.WriteLine("empid");
            employee.empid= Console.ReadLine();
            Console.WriteLine("basic");
            employee.basic = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("sa");
            employee.special_allowance = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("pb");
            employee.bonus_percentage = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("enter tax saving investments");
            employee.tax_saving_investments = Convert.ToDouble(Console.ReadLine());
            display_result(employee);
        }
        public static void display_result(Employee e)
        {
            double monthly_gross = e.basic + e.special_allowance;
            double anual_salary = monthly_gross * 12;
            e.gross_anual_salary = anual_salary + (anual_salary * e.bonus_percentage) / 100;
            double final_salary = e.compute_salary();
            Console.WriteLine($"your anual gross is = {e.gross_anual_salary}\n your net annual = {final_salary}");
            Console.WriteLine("your tax payable = " + e.tax_payable);
        }
    }
    internal class Employee{
        public string name, empid;
        public double basic, special_allowance, bonus_percentage, tax_saving_investments;
        public double gross_anual_salary;
        public double tax_payable;
        
        public double compute_salary() {
            double final_salary=0;
            if(tax_saving_investments <= gross_anual_salary)
            {
                if(tax_saving_investments == 0)
                {
                    if(gross_anual_salary == 100000)
                    {
                        final_salary = gross_anual_salary;
                        tax_payable = 0;
                        return final_salary;
                    }
                }
                else if(tax_saving_investments <= 100000)
                {
                    final_salary = gross_anual_salary - tax_saving_investments;
                    if(final_salary <= 100000)
                    {
                        tax_payable = 0;
                        return final_salary;
                    }
                    else if(final_salary > 100000 && final_salary <= 150000)
                    {
                        tax_payable = final_salary * 0.2;
                        final_salary = final_salary - tax_payable;
                        return final_salary;
                    }
                    else
                    {
                        tax_payable = final_salary * 0.3;
                        final_salary = final_salary - final_salary * 0.3;
                        return final_salary;
                    }
                }
            }
            else
            {
                Console.WriteLine("you entered tax savings investment higher than your salary");
                Environment.Exit(0);
            }
            return final_salary;
        }
    }
}
