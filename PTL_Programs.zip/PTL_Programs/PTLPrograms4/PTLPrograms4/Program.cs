﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms4
{
    internal class Program
    {

        static void Main()
        {
            double val;
            Console.WriteLine("Enter a double number:");
            val = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine($"The value is {val}");

            int integerPart = (int)val;
            double decimalPart = val - (double)integerPart;

            int decimalPlaces = GetDecimalPlaces(val);
            double roundedDecimalPart = Math.Round(decimalPart, decimalPlaces);

            Console.WriteLine($"The integer part is = {integerPart}");
            Console.WriteLine($"The decimal part is = {roundedDecimalPart}");

            
        }

        
        static int GetDecimalPlaces(double value)
        {
            string[] parts = value.ToString().Split('.');
            return parts.Length > 1 ? parts[1].Length : 0;
        }
    }
}
