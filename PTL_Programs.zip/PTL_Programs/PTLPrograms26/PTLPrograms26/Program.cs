﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms26
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*26. Write a pseudocode to store N elements in an array of integer. Display the 
elements. Accept a number to be searched. Display whether the number is found 
or not in the array (LINEAR SEARCH). */

            Console.Write("Enter size");
            int n = Convert.ToInt32(Console.ReadLine());

            int[] arr = new int[n];
            Console.WriteLine("Enter array");
            for (int i = 0; i < n; i++)
            {
                Console.Write($"Element {i + 1}: ");
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
           
           Console.WriteLine("\nDisplaying");
            for (int i = 0; i < n; i++)
            {
                Console.Write(arr[i] + " ");
            }
            
            Console.Write("\nEnter the number to be searched: ");
            int searchNumber = Convert.ToInt32(Console.ReadLine());
           
            bool found = false;
            for (int i = 0; i < n; i++)
            {
                if (arr[i] == searchNumber)
                {
                    found = true;
                    break;
                }
            }           
            if (found)
            {
                Console.WriteLine($"{searchNumber} is found");
            }
            else
            {
                Console.WriteLine($"{searchNumber} is not found");
            }
        }
    }
}
