﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms16
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
             16. Write a pseudocode to accept a binary number and display it in the decimal 
            form. 
             */
            Console.WriteLine("enter a binary number");
            string b = Console.ReadLine();

            func(b);
            
            
        }
        public static void func(string b)
        {
            for (int i = 0; i < b.Length; i++)
            {
                if (b[i] != '0' && b[i] != '1')
                {
                    Console.WriteLine("not binary");
                    Environment.Exit(0);
                }
            }
            int ans = 0;
            int len = b.Length;
            for (int i = b.Length - 1; i >= 0; i--)
            {

                ans += (b[i] - '0') * ((int)Math.Pow(2, len - i - 1));
            }
            Console.WriteLine(ans);
        }
    }
}
