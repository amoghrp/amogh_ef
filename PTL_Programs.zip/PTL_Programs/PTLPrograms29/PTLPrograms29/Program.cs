﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms29
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*29. Write a pseudocode to store elements into a N * N matrix of integer. Display 
whether it is an identity matrix or not. */
            Console.Write("Enter  size o ");
            int N = Convert.ToInt32(Console.ReadLine());

            int[,] matrix = new int[N, N];

          
            Console.WriteLine("Enter the elements :");
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    
                    matrix[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

           
            Console.WriteLine("\nThe matrix is:");
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    Console.Write(matrix[i, j] + " ");
                }
                Console.WriteLine();
            }

            
            bool isIdentity = true;
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    if ((i == j && matrix[i, j] != 1) || (i != j && matrix[i, j] != 0))
                    {
                        isIdentity = false;
                        break;
                    }
                }
                if (!isIdentity)
                {
                    break;
                }
            }

            
            if (isIdentity)
            {
                Console.WriteLine("\nThe matrix is an identity matrix.");
            }
            else
            {
                Console.WriteLine("\nThe matrix is not an identity matrix.");
            }
        }
    }
}
