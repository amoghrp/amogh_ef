﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /* 
             * 
             13. Write a pseudocode to find the sum of all the prime numbers in the range n to m. 
            Display each prime number and also the final sum. 
             */

            int n, m;
            Console.WriteLine("enter n and m");
            n = Convert.ToInt32(Console.ReadLine());
            m = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            int sum = 0;
            for(int i = n; i <= m; i++)
            {
                if (isPrime(i))
                {
                    sum += i;
                    Console.Write(i + " ");
                }
            }
            Console.WriteLine();

        }
        public static bool isPrime(int number)
        {
            if (number <= 1)
                return false;

            for (int i = 2; i <= Math.Sqrt(number); i++)
            {
                if (number % i == 0)
                    return false;
            }

            return true;
        }
    }
}
