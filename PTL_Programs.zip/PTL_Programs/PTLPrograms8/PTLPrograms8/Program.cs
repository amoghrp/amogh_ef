﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms8
{
    class VendorService
    {
        private double resourceRatePerHour;
        private double hardwareCost;
        private double softwareCost;
        private double consultantRatePerHour;

        public VendorService(double resourceRatePerHour, double hardwareCost, double softwareCost, double consultantRatePerHour)
        {
            this.resourceRatePerHour = resourceRatePerHour;
            this.hardwareCost = hardwareCost;
            this.softwareCost = softwareCost;
            this.consultantRatePerHour = consultantRatePerHour;
        }

        public double CalculateTotalCost(int totalHours)
        {
            double totalCost = totalHours * resourceRatePerHour;

            if (hardwareCost > 0)
            {
                totalCost += hardwareCost;
            }

            if (softwareCost > 0)
            {
                double clientSoftwarePayment = softwareCost * (softwareCost > 100 ? 1 : 0.5);
                totalCost += clientSoftwarePayment;
            }

            return totalCost;
        }

        public double CalculateProfitOrLoss(int totalHours)
        {
            double totalCost = CalculateTotalCost(totalHours);
            double consultantCost = totalHours * consultantRatePerHour;
            double totalRevenue = totalCost + consultantCost;
            return totalRevenue - totalCost;
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("dollar rate per hour for vendor resss");
            double resourceRatePerHour = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("hardware/vendor cost...:");
            double hardwareCost = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("software licenses costs vendor");
            double softwareCost = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("dollar rate per hour for external people..");
            double consultantRatePerHour = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("total hours by all vendor :");
            int totalHours = Convert.ToInt32(Console.ReadLine());

            VendorService vendorService = new VendorService(resourceRatePerHour, hardwareCost, softwareCost, consultantRatePerHour);

            double profitOrLoss = vendorService.CalculateProfitOrLoss(totalHours);

            if (profitOrLoss > 0)
            {
                Console.WriteLine($" profit of ventor =${profitOrLoss}");
            }
            else if (profitOrLoss < 0)
            {
                Console.WriteLine($"loss is = ${-profitOrLoss}");
            }
            else
            {
                Console.WriteLine("no gain, no loss");
            }
        }
    }
}