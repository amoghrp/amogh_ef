﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms5
{
    internal class Program
    {
        static void Main(string[] args)
        {

            string name;
            int sub1 = 0;
            int sub2 = 0;
            int sub3 = 0;
            Console.WriteLine("enter name of student");
            name = Console.ReadLine();
            Console.WriteLine("enter marks in subject_1");
            sub1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter marks in subject_2");
            sub2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter marks in subject_3");
            sub3 = Convert.ToInt32(Console.ReadLine());
            if(sub1>=0 && sub1 <=100 && sub2 >=0 && sub2 <=100 && sub3 >=0 && sub3 <= 100)
            {
                display_data(name, sub1, sub2, sub3);
            }
            else
            {
                Console.WriteLine("you have entered invalid marks for one or more subjects....\n enter valid marks");
                Environment.Exit(0);
            }
            

        }
        static void display_data(string name,int a,int b,int c) {
            Console.WriteLine($"hello {name}");
            int total = a + b + c;
            double avg = (double)total / 3;
            Console.WriteLine($"your total marks is = {total}");
            Console.WriteLine($"your average marks is = {avg}");
            double percentage = (double)total / 3;
            /*
            * 5. Write a pseudocode to accept a student’s name and scores in three subject. Display the 
            average and total. Display whether the student has secured 1st, 2nd, pass class or has 
            failed. 1st class is for a score of 60 and above, 2nd is for a score of 50 and above, while 
            pass class is for a score of 35 and above. If the score is less than 35, then the student 
            fails.

            */
            Console.WriteLine("subject 1 results :");
            if (a >= 60)
            {
                Console.WriteLine("congrats you have secured 1st class in subject 1");
            }
            else if(a >= 50)
            {
                Console.WriteLine("congrats you have secured 2nd class in subject 1");
            }
            else if(a >= 35)
            {
                Console.WriteLine("good you have passed in subject 1");
            }
            else
            {
                Console.WriteLine("sorry, you have failed in subject 1");
            }


            Console.WriteLine("subject 2 results :");
            if (b >= 60)
            {
                Console.WriteLine("congrats you have secured 1st class in subject 2");
            }
            else if (b >= 50)
            {
                Console.WriteLine("congrats you have secured 2nd class in subject 2");
            }
            else if (b >= 35)
            {
                Console.WriteLine("good you have passed in subject 2");
            }
            else
            {
                Console.WriteLine("sorry, you have failed in subject 2");
            }


            Console.WriteLine("subject 3 results :");
            if (c >= 60)
            {
                Console.WriteLine("congrats you have secured 1st class in subject 3");
            }
            else if (c >= 50)
            {
                Console.WriteLine("congrats you have secured 2nd class in subject 3");
            }
            else if (c >= 35)
            {
                Console.WriteLine("good you have passed in subject 3");
            }
            else
            {
                Console.WriteLine("sorry, you have failed in subject 3");
            }


        }
    }
}
