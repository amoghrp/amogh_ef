﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms_7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
            7. Write a pseudocode to accept name, empId, basic, special allowances, percentage of 
bonus and monthly tax saving investments. The gross monthly salary is basic + special 
allowances. Compute the annual salary. The gross annual salary also includes the bonus. 
Compute the annual net salary, by deducting taxes as suggested. 
Income upto 1 lac – exempted 
Income from 1 to 1.5 lac – 20% 
Income from 1.5 lac onwards – 30% 
However if there is any tax saving investment, then there is further exemption of upto 1 
lac annually. This would mean that by having tax saving investments of about 1 lac, an 
income of 2 lacs is non-taxable. Display the annual gross, annual net and tax payable.
 
            */
            emp e = new emp();
            Console.WriteLine("enter employee details");
            e.name = Console.ReadLine();
            e.empid = int.Parse(Console.ReadLine());
            e.basic = int.Parse(Console.ReadLine());
            e.specialallowance = int.Parse(Console.ReadLine());
            e.bonusper = double.Parse(Console.ReadLine());
            e.investments = int.Parse(Console.ReadLine());
            e.annualsal();
            e.grosssal();
            e.annualnet();


        }

    }
    public class emp
    {
        double sal, grossal, annet;
        public string name
        {
            get; set;
        }
        public int empid { get; set; }
        public int basic { get; set; }
        public int specialallowance { get; set; }
        public double bonusper { get; set; }
        public int investments { get; set; }
        public void annualsal()
        {
            sal = (basic + specialallowance) * 12;
            Console.WriteLine($"details of {name} ");
            Console.WriteLine($"sal is {sal}");

        }
        public void grosssal()
        {

            grossal = sal + (sal * bonusper) / 100;
            Console.WriteLine($"sal is {grossal}");
        }
        public void annualnet()
        {
            if (grossal > 100000)
            {
                if (investments * 12 > 100000)
                {
                    annet = grossal - 100000;
                }
                else
                {
                    annet = grossal - investments * 12;
                }
            }
            else
            {
                annet = grossal;
                Console.WriteLine($"annual net salary is {annet} taxable is " + 0);
                return;
            }
            double taxablesal;
            if (annet > 100000 && annet <= 150000)
            {
                annet = annet * .8;
                taxablesal = 50000;
            }
            else if (annet > 150000)
            {


                taxablesal = annet - 150000;
                annet = annet - .3 * taxablesal - 10000;
                taxablesal += 50000;
            }
            else
            {
                annet = grossal;

                // Console.WriteLine($"gross sal{grossal} and annet {annet}");
            }
            if (investments * 12 > 100000)
            {
                annet = annet + 100000;
            }
            else
            {
                annet = annet + investments * 12;
            }
            Console.WriteLine($"annual net salary is {annet}");
        }
    }

}