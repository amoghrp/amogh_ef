﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
             9. Write a pseudocode to find the sum of all odd numbers from 1 to N.
            Accept N. Display the sum.
             */
            Console.WriteLine("enter n");
            int n = Convert.ToInt32(Console.ReadLine());
            int s = find_sum_of_odd(n);
            Console.WriteLine(s);
        }
        private static int find_sum_of_odd(int n)
        {
            int sum = 0;
            for(int i = 1; i <= n; i+=2)
            {
                sum += i;
            }
            return sum;
        }
    }
}
