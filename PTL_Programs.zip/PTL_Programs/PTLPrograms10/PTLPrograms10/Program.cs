﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTLPrograms10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
             10. Write a pseudocode to find the reverse of a number. Store the reverse value 
             in a different variable. Display the reverse. 
            */
            int n;
            Console.WriteLine("enter number to reverse");
            n = Convert.ToInt32(Console.ReadLine());
            int ans=0;
            while (n>0)
            {
                int r = n % 10;
                ans = ans * 10 + r;
                n /= 10;
            }
            Console.WriteLine(ans);
        }
    }
}
