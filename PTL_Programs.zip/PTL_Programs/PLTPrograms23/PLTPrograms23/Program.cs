﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PLTPrograms23
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
             23. Write the pseudocodes to generate the following outputs. 
            In all the following cases, 
                accept N: 
                * * * * * 
                * * * * * 
                * * * * * 
                * * * * * 

             */
            Console.WriteLine("enter number");
            int n = Convert.ToInt32(Console.ReadLine());
            
            pattern4(n);

        }

        public static void pattern1(int n)
        {
            for(int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write("* ");
                }
                Console.WriteLine();
            }
        }
        public static void pattern2(int n)
        {
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write($"{i+1} ");
                }
                Console.WriteLine();
            }
        }
        public static void pattern3(int n)
        {
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write($"{j + 1} ");
                }
                Console.WriteLine();
            }
        }
        public static void pattern4(int n)
        {
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if(i>=j)
                    Console.Write($"* ");
                    else
                        Console.Write(" ");
                }
                Console.WriteLine();
            }
        }
    }
}
