﻿using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program1
{
    internal class Program
    {
        private static readonly Logger logger = LogManager.GetCurrentClassLogger();
        static void Main(string[] args)
        {
            /* try
             {
                 throw new NotImplementedException();
             }
             catch(Exception e) {

                 logger.Info(e.Message);
                 logger.Error("hello iam sudeep");
                 logger.Debug(e.StackTrace);
             }*/

            var logger = LogManager.GetCurrentClassLogger();

            logger.Properties.Add("userId", "amogh");
            logger.Properties.Add("sessionId", "333");


            MappedDiagnosticsContext.Set("MethodName", "Main");
            MappedDiagnosticsContext.Set("ErrorCode", "12345");


            logger.Info("");


            


        }
    }
}
