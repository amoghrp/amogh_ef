﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesDemo1
{
    internal class Program
    {
        

        // steps for delegate
        // step 1 -> delegate declaration (class level) signature of method
        // (in this case any method that takes string and return type of void)
        // step 2 -> instantiation and initialization
        // step 3 -> invocation
        public delegate void MyDelegate(string str);

        public delegate void MyDelegate2();
        // Multicast delegate 


        static void Main(string[] args)
        {
            // 1) Direct method invocation
            // to call a method I must know all the below info
            // method name 
            // signature of the method
            // type of the method instance or static
            // class name of the method
            // namespace and assembly


            // Indirect method call - by its address 
            // (by knowing just the address of the method and signature)
            // there is a class called Delegate


            //Greeting("hello world"); ----> Direct method call

            /* Delegate d = new Delegate();*/  // incorrect 

            // step 2 instantiation and initialization
            // here in parameter we have to pass the 
            MyDelegate del = new MyDelegate(Greeting);
            // OR
            del = Greeting;
           
            // step3 -> invocation
            // two ways of invocation
            del.Invoke("amogh");
            del("abcd");
            Program program = new Program();
            
            del += program.Hi;
           
            
           
            del("------");

            Console.WriteLine("here");
            MyDelegate del2 = new MyDelegate(program.Hi);
           del2("bro");
           // one more way
           del = program.Hi;   // this is called subscription
           del("one more way");

           MyDelegate2 dl = new MyDelegate2(program.Hello);

           dl.Invoke();




        }

        public void Hello()
        {
            Console.WriteLine("inside_hello");
        }

        public void Hi(string str)
        {
            Console.WriteLine($"Hi: {str}");
        }
        static void Greeting(string msg) {
            Console.WriteLine($"greeting : {msg}");
        }
    }
}
