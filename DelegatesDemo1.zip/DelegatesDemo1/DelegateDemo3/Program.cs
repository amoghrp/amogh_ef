﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
                
            
            List<int> list = new List<int>() {1,2,3,4,5,6,7,8,9 };

            // find the sum

            int sum = list.Sum();
            Func<int, bool> filter = new Func<int, bool>(IsEven); 
            // wrapping the is even method in in-built delegate called Func
            // Where is a LINQ method that will take a method address (through name or delegage object)
            // that is of signature determined by in-built generic Func<> delegate class
            int evensSum = list.Where(filter).Sum();
            int evenSum2 = list.Where(IsEven).Sum();

            // lambda statement
            int evenSum3 = list.Where( 
                delegate (int x)
                {
                return x % 2 == 0;
            }).Sum();

            
            int evenSum4 = list.Where(
                 (int x) =>
                {
                    return x % 2 == 0;
                }).Sum();

            // lambda expression
            int evenSum5 = list.Where(
                 (int x) =>

                      x % 2 == 0 
                 ).Sum();


            int evenSum6 = list.Where(x => x % 2 == 0).Sum();

        }

        public static bool IsEven(int x)
        {
            return x % 2 == 0;
        }

    }
}
