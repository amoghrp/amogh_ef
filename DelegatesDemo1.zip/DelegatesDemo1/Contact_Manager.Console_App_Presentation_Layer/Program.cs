﻿using Contact_Manager.Common_Layer;
using Contact_Manager.Data_Layer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contact_Manager.Console_App_Presentation_Layer
{
    internal class Program
    {
        private static ContactsFileRepository cfr = new ContactsFileRepository();
        static void Main(string[] args)
        {
             
            while (true)
            {
                Console.WriteLine("contact Manager");
                Console.WriteLine("=============");
                Console.WriteLine("1. create contact");
                Console.WriteLine("2. get all contacts");
                Console.WriteLine("3. get contact by id");
                Console.WriteLine("4. edit contact");
                Console.WriteLine("5. delete contact");
                Console.WriteLine("6. exit");
                Console.WriteLine("---------------------");
                Console.WriteLine("enter your choice [1-6] ");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1: CreateContact();break;
                    case 2: GetAllContacts();break;
                    case 3: GetContactById();break;
                    case 4: EditContact(); break; 
                    case 5: DeleteContactById(); break;
                    case 6: Environment.Exit(0);break;
                    default: Console.WriteLine("invalid choice");break;
                }
            }
        }

        private static void DeleteContactById()
        {
            Console.WriteLine("enter id");
            int id = int.Parse(Console.ReadLine());
            Contact c = Program.cfr.GetContactByID(id);
            if (c == null)
            {
                Console.WriteLine(" can't delete contact does not exist");
            }
            else
            {
                cfr.DeleteContactByID(id);
            }
        }

        private static void EditContact()
        {
            Console.WriteLine("enter id");
            int id = int.Parse(Console.ReadLine());
            Contact c = Program.cfr.GetContactByID(id);
            if (c == null)
            {
                Console.WriteLine(" can't edit contact does not exist");
            }
            else
            {
                Console.WriteLine("enter new details to update/edit");
                Console.WriteLine("new contact id :");
                c.ContactID = int.Parse(Console.ReadLine());
                Console.WriteLine("new contact name");
                c.Name = Console.ReadLine();
                Console.WriteLine("new mobile no");
                c.Mobile = Console.ReadLine();
                Console.WriteLine("new email id");
                c.Email = Console.ReadLine();
                Console.WriteLine("new location :");
                c.Location = Console.ReadLine();



                cfr.UpdateContact(c,id);
            }
            
        }

        private static void GetContactById()
        {
            Console.WriteLine("enter id");
            int id = int.Parse(Console.ReadLine());

            Contact c = Program.cfr.GetContactByID(id);
            if(c == null)
            {
                Console.WriteLine("contact does not exist");
            }
            else
            {
                PrintContact(c);
            }
        }
        public static void PrintContact(Contact contact)
        {
            Console.WriteLine($"{contact.ContactID},{contact.Name},{contact.Mobile},{contact.Email},{contact.Location}");
        }

        public static void  GetAllContacts()
        {
            List<Contact> contactslist = Program.cfr.GetAllContacts(); // method in contact file repo
            if(contactslist == null)
            {
                Console.WriteLine("contact list is empty");
                return;
            }
            foreach (Contact contact in contactslist)
            {
                PrintContact (contact);
            }

        }

        public static void CreateContact()
        {
            // save contact info
            Contact c = new Contact();
            Console.WriteLine("contact id :");
            c.ContactID = int.Parse(Console.ReadLine());
            Console.WriteLine("contact name");
            c.Name = Console.ReadLine();
            Console.WriteLine("mobile no");
            c.Mobile = Console.ReadLine();
            Console.WriteLine("email id");
            c.Email = Console.ReadLine();
            Console.WriteLine("location :");
            c.Location = Console.ReadLine();

            IContactsRepository repository = new ContactsFileRepository();
            repository.Save(c);
            Console.WriteLine("contact saved successfully");
        }
    }
}
