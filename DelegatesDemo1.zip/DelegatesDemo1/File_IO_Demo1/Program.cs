﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace File_IO_Demo1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            


            

        }
        public static void ReadLineByLine()
        {
            string readLine;
            using (StreamReader r = new StreamReader(@"C:\Users\AMOGH PATIL\Desktop\demo\names.txt"))
            {
                while (!r.EndOfStream)
                {
                    readLine = r.ReadLine();
                    Console.WriteLine(readLine);
                }
            }
        }

        public static void ReadAll()
        {
            // read data from names.txt
            string readAllLines;
            using (StreamReader r = new StreamReader(@"C:\Users\AMOGH PATIL\Desktop\demo\names.txt"))
            {
                // read all lines at once
                readAllLines = r.ReadToEnd();

            }

            Console.WriteLine(readAllLines);
        }
        public static void WriteData()
        {
            StreamWriter writer = null;
            /*try
            {*/
            // collect person name from user and store into file
            Console.WriteLine("enter name ");
            string name = Console.ReadLine();

            writer = new StreamWriter("C:\\Users\\AMOGH PATIL\\Desktop\\demo\\names.txt", true);
            using (writer)
            {
                writer.WriteLine(name);
            }
            // if names.txt exists then it opens else creates
            /*writer.WriteLine(name);
            writer.WriteLine("hello");*/
            //}
            /*catch (Exception ex)
            {

            }
            finally
            {
                writer.Close();
            }*/
        }
    }
}
