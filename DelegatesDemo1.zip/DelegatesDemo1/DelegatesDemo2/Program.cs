﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesDemo2
{
    // application and use cases of delegate
    internal class Program
    {
        static void Main(string[] args)
        {
            // client 1 requirement is 
            // display all processes
            // ProcessManager.ShowProcessList();

            // client 2 comes
            // requrirement is display all processes whoes names starts with S 
            /* FilterDelegate fil = new FilterDelegate(Program.FilterByName);
             ProcessManager.ShowProcessList(fil);*/

            // client 3 display all large processes
            // ProcessManager.ShowProcessList(FilterBySize);
            // client 3 wants to call only once
            // anonymous delegates 


            /*ProcessManager.ShowProcessList( 
                delegate (Process p)
                    {
                    return p.WorkingSet64 >= 100 * 1024 * 1024;
                    }
            );*/

            // Lambda - was brought to make the above anonymous delegate ligt weight ans easy
            // 2 types of lambda statement based and expression (only lambda expressions are lightweight)
            // know the difference between lambda expressions and lambda statements


            // now this below is called anonymous statement not light weight
            /*ProcessManager.ShowProcessList(
                delegate (Process p)
                {
                    return p.WorkingSet64 >= 100 * 1024 * 1024;
                }
            );*/



            // now this below is called anonymous expression light weight
            ProcessManager.ShowProcessList( (Process p) => p.WorkingSet64 >= 100 * 1024 * 1024 );
            // next level 
            // using type inference
            ProcessManager.ShowProcessList( p => p.WorkingSet64 >= 100 * 1024 * 1024 );
            // we will write tones of such code

        }

        // client 2
        public static bool FilterByName(Process p)
        {
            return p.ProcessName.StartsWith("s");
        }
        // client 3 
        public static bool FilterBySize(Process p)
        {
            return p.WorkingSet64 >= 100*1024*1024;
        }

    }

    public delegate bool FilterDelegate(Process p);

    // Backend Dev
    public class ProcessManager
    {
       /* public static void ShowProcessList()
        {
            // display all the running processes in current machine
            // there is a built in class called Process
            // namespace is System.Dignostic something
           // Process.GetProcesses(); // returns an array of processes

            foreach(Process p in Process.GetProcesses())
            {
                Console.WriteLine(p.ProcessName); // this is backend developer's code
            }
        }*/

       /* public static void ShowProcessList(string s)
        {
            // display all the running processes in current machine
            // there is a built in class called Process
            // namespace is System.Dignostic something
            // Process.GetProcesses(); // returns an array of processes

            foreach (Process p in Process.GetProcesses())
            {
                if (p.ProcessName.StartsWith (s))
                    Console.WriteLine(p.ProcessName); 
            }
        }*/

        // one single method 
        public static void ShowProcessList( FilterDelegate fil )
        {
            // display all the running processes in current machine
            // there is a built in class called Process
            // namespace is System.Dignostic something
            // Process.GetProcesses(); // returns an array of processes


            // now using delegates one single method can satisfy all client 
            // requirements and the requirements condition is given by the clients
            // through delegates 

            foreach (Process p in Process.GetProcesses())
            {
                if (fil(p)) 
                    Console.WriteLine(p.ProcessName);

            }
        }

    }

}
