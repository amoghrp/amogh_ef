﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Contact_Manager.Common_Layer;
namespace Contact_Manager.Data_Layer
{
    public interface IContactsRepository
    {
        void Save(Contact contact);
        List<Contact> GetAllContacts();
        Contact GetContactByID(int id);
        void DeleteContactByID(int id);
        void UpdateContact(Contact contact,int contactID);

    }



}
