﻿using Contact_Manager.Common_Layer;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contact_Manager.Data_Layer
{
    public class ContactsFileRepository : IContactsRepository
    {
        private readonly string file = "contacts.txt";
        public void DeleteContactByID(int id)
        {
            List<Contact> cl = new List<Contact>();
            cl = GetAllContacts();

            for (int i = 0; i < cl.Count; i++)
            {
                if (cl[i].ContactID == id)
                {
                    cl.RemoveAt(i);
                }
            }
            if (File.Exists(file))
            {
                File.Delete(file);
            }
            foreach(Contact c in cl)
            {
                Save(c);
            }
        }

        public List<Contact> GetAllContacts()
        {
            string contactRecord;
            List<Contact > l = new List<Contact>();
            if (File.Exists(file))
            {
                long length = new FileInfo(file).Length;
                if(length ==0)
                {
                    return null;
                }
            }
            using(StreamReader sr = new StreamReader(file))
            {
                while (!sr.EndOfStream)
                {
                    Contact c = new Contact();
                    contactRecord = sr.ReadLine();
                    string[] contactFields = contactRecord.Split(',');
                    c.ContactID = Convert.ToInt32(contactFields[0]);
                    c.Name = contactFields[1];
                    c.Mobile = contactFields[2];
                    c.Email = contactFields[3];
                    c.Location = contactFields[4];
                    l.Add(c);

                }

            }
            
            return l;
        }

        public Contact GetContactByID(int id)
        {
            using(StreamReader sr = new StreamReader(file))
            {
                while (!sr.EndOfStream)
                {
                    Contact c = new Contact();
                    string contactRecord = sr.ReadLine();
                    string[] contactFields = contactRecord.Split(',');
                    int cid = Convert.ToInt32(contactFields[0]);
                    if(cid == id)
                    {
                        c.ContactID = Convert.ToInt32(contactFields[0]);
                        c.Name = contactFields[1];
                        c.Mobile = contactFields[2];
                        c.Email = contactFields[3];
                        c.Location = contactFields[4];
                        return c;
                    }
                }
            }
            return null;
        }

        public void Save(Contact contact)
        {
            // here we have to convert the logical contact object into a csv format 
            // this process is called as a serialization
            using(StreamWriter writer = new StreamWriter(file,true))
            {
                // contact => CSV 111,ramesh,ramesh@gmail.com,23232,banglore
                string contactCsv = $"{contact.ContactID},{contact.Name},{contact.Mobile},{contact.Email},{contact.Location}";
                writer.WriteLine(contactCsv);
            }
        }

        public void UpdateContact(Contact contact, int contactID)
        {
            List<Contact> cl = new List<Contact>();
            cl = GetAllContacts();

            for(int i = 0; i < cl.Count; i++)
            {
                if (cl[i].ContactID == contactID)
                {
                    cl[i] = contact;
                }
            }
            if (File.Exists(file))
            {
                // Delete the file
                File.Delete(file);
                
            }

            foreach(Contact c in cl)
            {
                Save(c);
            }

        }
    }
}
