﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace Delegates_Demo_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // client dev 1 
            Account account = new Account();
            account.Notify += Notification.SendMail; // client subscribed for mails
            account.Notify += Notification.SendSMS;

            // unsubscribe
            account.Notify -= Notification.SendMail;
            account.Notify += Notification.SendWA;
            //account.Notify("deposited 9999"); // invalid because it is an event

            account.Deposit(1000);
            Console.WriteLine($"balance : { account.Balance} ");
            account.WithDrawal(500);
            Console.WriteLine($"Balance : {account.Balance}");



        }
    }


    

    // DEV 1 author of the class
    public class Account // Business class
    {
        public int Balance { get; set; }
        public event NotifyDelegate Notify = null;   // new NotifyDelegate(Notification.SendMail);

        /*public void Subscribe(NotifyDelegate notify)
        {
            Notify += notify;
        }*/

        public void Deposit(int amount)
        {
            Balance += amount;
            //  Console.WriteLine("deposited");
            string msg = $"{amount} rs is deposited";
            //Notification.SendMail("");
            //Notification.SendSMS(msg);
            if (Notify != null)
                Notify(msg);
            
        }

        
        public void WithDrawal(int amount)
        {
            Balance -= amount;
            //Console.WriteLine("withdrawn");
            string msg = $"{amount} rs is withdraw";
            //Notification.SendMail($"{amount} rs is withdrawn");
            //Notification.SendSMS(msg);
            if (Notify != null)
                Notify(msg);
        }
    }

    public delegate void NotifyDelegate(string msg);

    //dev 2
    public class Notification
    {
        public static void SendMail(string msg)
        {
            // send an email notification
            SmtpClient client = new SmtpClient();
            //client.Port = 465;
            //client.Host = "smtp.gmail.com";
            client.DeliveryMethod = SmtpDeliveryMethod.SpecifiedPickupDirectory;
            client.PickupDirectoryLocation = "C:\\Users\\AMOGH PATIL\\Documents\\mails";
            client.Credentials = null; // user id and password
            MailMessage message = new MailMessage("fromxyzBankManager@xyzbank.com", "tocustomer@mail.com");
            message.Subject = msg;
            message.Body = msg;
            //message.Attachments.Add("");
            client.Send(message);
            Console.WriteLine($"email :{msg}");
        }

        public static void SendSMS(string msg)
        {
            Console.WriteLine($"SMS : {msg} ");
        }
        public static void SendWA(string msg)
        {
            Console.WriteLine($"whatsapp {msg}");
        }
    }
}
