﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exceptions_lab_assessment_1
{
    public class Program
    {
        static void Main(string[] args)
        {
            // task 1
            Console.WriteLine("enter a phone number");
            string s = Console.ReadLine();

            MobileNumberValidator v = new MobileNumberValidator();
            bool flag = v.IsValidPhoneNumber(s);

            if (flag)
                Console.WriteLine("success valid number...");

            // task 2
             method_e_2();
            // task 3
            vehicle_class_3();
            Console.WriteLine("terminating normally");
        }

        public static void vehicle_class_3()
        {
            Vehicle v = new Vehicle();
            try
            {

                v.IncreaseSpeed(30);
                v.IncreaseSpeed(35);
            }
            catch(SpeedMoreThanMaximumSpeedException ex)
            {
                Console.WriteLine(ex.GetType().Name);
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.InnerException.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.GetType().Name);
                Console.WriteLine(ex.Message);
            }

        }
        public static void method_e_2()
        {
            try
            {
                Console.WriteLine("file operations");
                StreamReader sr = File.OpenText("C:/Users/amogh_exceptions_test.txt");
                int a, b, r;
                a = int.Parse(sr.ReadLine());
                b = int.Parse(sr.ReadLine());
                r = a / b;
                Console.WriteLine("r="+r);
                sr.Close();
            }
            catch(FileNotFoundException ex)
            {
                Console.WriteLine(ex.GetType().Name);
                Console.WriteLine(ex.Message);
            }
            catch (OverflowException ex)
            {
                Console.WriteLine(ex.GetType().Name);
                Console.WriteLine(ex.Message);
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine(ex.GetType().Name);
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.GetType().Name);
                Console.WriteLine(ex.Message);
            }
        }
    }

    public class Vehicle
    {
        public double CurrentSpeed { get; private set; }
        public double MaximumSpeed { get;  }

        public Vehicle()
        {
            CurrentSpeed = 0;
            MaximumSpeed = 60;
        }
        public void IncreaseSpeed(double inc)
        {
            if(CurrentSpeed+inc > MaximumSpeed)
            {
                throw new SpeedMoreThanMaximumSpeedException("high speed");
            }
            CurrentSpeed+= inc;
            Console.WriteLine("current speed"+CurrentSpeed);
        }

    }
    public class SpeedMoreThanMaximumSpeedException : ApplicationException
    {
        public Exception InnerException { get; private set; }
        public string errorMessage { get; } = "throwing this speed exception";

        public  SpeedMoreThanMaximumSpeedException(string errorMessage) : base(errorMessage)
        {
            this.InnerException = new OverflowException();
        }
    }


    /// <summary>
    /// invalid phone number exception
    /// </summary>
    public class InvalidMobileNumberException : ApplicationException
    {
        public InvalidMobileNumberException(string msg) : base(msg)
        {

        }

    }
    /// <summary>
    /// Mobile no validator
    /// </summary>
    public class MobileNumberValidator
    {
        /// <summary>
        /// IsValid phone number method
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public bool IsValidPhoneNumber(string str)
        {
            

            try
            {
               
                if (str == null) throw new NullReferenceException("referencing null");

            }
            catch(NullReferenceException ex)
            {
                Console.WriteLine(ex.GetType().Name);
                Console.WriteLine(ex.Message);
                return false;
            }

            if(str.Length !=10 || !HasOnlyDigits(str) || str[0] != '9' )
            {
                
                try
                {
                    
                    throw new InvalidMobileNumberException("you entered invalid number");

                }
                catch (InvalidMobileNumberException ex)
                {
                    Console.WriteLine(ex.GetType().Name);
                    Console.WriteLine(ex.Message);
                    return false;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.GetType().Name);
                    Console.WriteLine(ex.Message);
                    return false;
                }
            }
            return true;
        }
        /// <summary>
        /// hasonlydigits
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public bool HasOnlyDigits(string str)
        {
            for(int i=0; i<str.Length; i++)
            {
                if (!('0'<= str[i] && str[i] <= '9'))
                {
                    return false;
                }
            }
            return true;
        }
    }

}
/*

using System;

public class Vehicle
{
    // Properties
    public int CurrentSpeed { get; private set; }
    public int MaximumSpeed { get; }

    // Constructor
    public Vehicle(int maximumSpeed)
    {
        MaximumSpeed = maximumSpeed;
        CurrentSpeed = 0;
    }

    // Method to increase speed
    public void IncreaseSpeed(int speedIncrement)
    {
        if (CurrentSpeed + speedIncrement > MaximumSpeed)
        {
            // If speed exceeds maximum, throw custom exception
            throw new SpeedMoreThanMaximumSpeedException("Speed exceeds maximum limit.");
        }

        CurrentSpeed += speedIncrement;
        Console.WriteLine($"Current Speed: {CurrentSpeed}");
    }
}

// Custom exception class
public class SpeedMoreThanMaximumSpeedException : ApplicationException
{
    // Fields
    private readonly Exception innerException;

    // Properties
    public override string Message => "Speed exceeds maximum limit.";
    public Exception InnerException => innerException;

    // Constructor
    public SpeedMoreThanMaximumSpeedException(string errorMessage, Exception innerException = null)
        : base(errorMessage)
    {
        this.innerException = innerException;
    }
}

class Program
{
    static void Main()
    {
        try
        {
            // Create a vehicle with a maximum speed of 100
            Vehicle car = new Vehicle(100);

            // Increase speed, triggering the custom exception
            car.IncreaseSpeed(120);
        }
        catch (SpeedMoreThanMaximumSpeedException ex)
        {
            Console.WriteLine($"Caught Custom Exception: {ex.Message}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Caught General Exception: {ex.Message}");
        }
    }
}
 
*/