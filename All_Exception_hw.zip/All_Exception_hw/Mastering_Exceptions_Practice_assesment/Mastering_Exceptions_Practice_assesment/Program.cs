﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mastering_Exceptions_Practice_assesment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //basic_1();


        }
        public static void basic_1()
        {
            int[] arr = { 1, 2, 3 ,4,5};
            Console.WriteLine("enter a number");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter b");
            int b = Convert.ToInt32(Console.ReadLine());
            int r = 0;
            try
            {
                r = a / b;

                Console.WriteLine(arr[6]);

            }
            catch(IndexOutOfRangeException ex)
            {
                Console.WriteLine(ex.GetType().Name);
                Console.WriteLine(ex.Message);
            }
            catch(DivideByZeroException ex)
            {
                Console.WriteLine("you can't divide by zero");
                Console.WriteLine(ex.GetType().Name);
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.GetType().Name);
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("try catch block is complete");
            }
            Console.WriteLine("res = "+r);
        }

    }
}
