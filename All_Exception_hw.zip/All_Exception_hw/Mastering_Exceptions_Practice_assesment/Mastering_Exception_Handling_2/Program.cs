﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mastering_Exception_Handling_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //method_1();
            //method_2();
            try 
            {
                method_3(); // for throw ex; check
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                // here it only prints stack trace from the most recent
                // throw ex; call it resets or removes all the previous deeper 
                // (original) stack trace(origin of exception is not considered)

            }

            try
            {
                method_33(); // for throw; check
            }
            catch(Exception ex)
            {
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine(ex.StackTrace); // this shows all till the root(origin of exception)
            }


        }
        public static void method_33()
        {
            method_44();
        }
        public static void method_44()
        {
            method_55();
        }
        public static void method_55()
        {
            method_66();

        }
        public static void method_66()
        {
            try
            {
                throw new NotImplementedException();
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public static void method_3()
        {
            try
            {
                method_4();
            }
            catch(Exception ex)
            {
                throw ex;
            }
           
        }
        public static void method_4()
        {
            method_5();
        }
        public static void method_5()
        {
            method_6();
        }

        public static void method_6()
        {
            try
            {
                throw new Exception("exp occured here");
            }
            catch(Exception ex)
            {
                throw;
            }
        }


        public static void method_2()
        {
            try
            {
                method_2_exception_propagator();
            }
            catch(ArithmeticException ex)
            {
                Console.WriteLine(ex.GetType().Name);
                Console.WriteLine(ex.Message);
            }
            Console.WriteLine("here");
        }

        public static void method_2_exception_propagator()
        {
            int a = int.MaxValue;
            int overflow_value = checked(a+1);
            Console.WriteLine(overflow_value);
        }
        public static void method_1()
        {
            try
            {
                string s = "12";
                int x = int.Parse(s); 
                Console.WriteLine("r = " + x);
                try
                {
                    int a = 35;
                    int b = 0;
                    int c = a / b;
                    Console.WriteLine("c = " + c);
                }
                catch (DivideByZeroException ex)
                {
                    Console.WriteLine(ex.GetType().Name);
                    Console.WriteLine(ex.Message);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.GetType().Name);
                    Console.WriteLine(ex.Message);
                }


            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.GetType().Name);
                Console.WriteLine(ex.Message);
            }
            catch(Exception ex) {
                Console.WriteLine("hhhhh");
                Console.WriteLine(ex.GetType().Name);
                Console.WriteLine(ex.Message);
            }
        }
    }
}
