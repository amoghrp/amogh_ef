﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mastering_Exceptions_part_3
{
    public class Program
    {
        static void Main(string[] args)
        {
            try
            {
                string a = Console.ReadLine();
                string b = Console.ReadLine();
                if(a==null || isNonNumeric(a))
                {
                    throw new InvalidInputException("-hello-non-numeric-",a);
                }
                if (b == null || isNonNumeric(b))
                {
                    throw new InvalidInputException("-hello-non-numeric-",b);
                }
                int x = int.Parse(a);
                int y = int.Parse(b); 
                if (y == 0) throw new InvalidInputException("-hello-divide-by-zero--",y.ToString());
                int c = (x/y);
                Console.WriteLine("c= "+c);
            }
            catch(InvalidInputException ex)
            {
                Console.WriteLine(ex.GetType().Name);
                Console.WriteLine(ex.Message+"please try later ");
                Console.WriteLine(ex.InputValue);
                Console.WriteLine(ex.ReasonForInvalidity);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.GetType().Name);
            }
        }
        public static bool isNonNumeric(string a)
        {
            foreach(char c in a)
            {
                if (!(c >= '0' && c <= '9'))
                    return true;
            }
            return false;
        }
    }
    public class  InvalidInputException : ApplicationException
    {
        public string InputValue { get; set; }
        public string ReasonForInvalidity {  get; set; }
        public InvalidInputException(string msg,string inp) : base(msg)
        {
            this.InputValue = inp;
            this.ReasonForInvalidity = $"input value {inp} is not valid for the operation";
        }
    }
}
