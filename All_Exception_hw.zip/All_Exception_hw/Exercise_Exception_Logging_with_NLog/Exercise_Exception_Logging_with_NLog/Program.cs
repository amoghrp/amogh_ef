﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NLog;
namespace Exercise_Exception_Logging_with_NLog
{
    
    internal class Program
    {
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        static void Main(string[] args)
        {
            try
            {

                int a = 25;
                Console.WriteLine("enter a number"); 
                int b = Convert.ToInt32(Console.ReadLine());
                int r = a / b;
            }
            catch (Exception ex)
            {

                Logger.Info("Hello------------ world");
                Logger.Debug("This is a debug message.");
                Logger.Info("This is an info message.");
                Logger.Warn("This is a warning message.");
                Logger.Error("This is an error message.");
                Logger.Fatal("This is a fatal message.");
                Console.WriteLine("Logging done. Press any key to exit...");
                Logger.Error(ex.GetType().Name, "Goodbye cruel world");
                
                
                
                /*// Set custom properties
                 part 3 (1,2) solution
                MappedDiagnosticsLogicalContext.Set("UserID", "user123");
                MappedDiagnosticsLogicalContext.Set("SessionID", Guid.NewGuid().ToString());

                // Log messages with custom properties
                Logger.Info("This is an info message with custom properties.");

                // Clear custom properties
                MappedDiagnosticsLogicalContext.Remove("UserID");
                MappedDiagnosticsLogicalContext.Remove("SessionID");

                Console.WriteLine("Logging done. Press any key to exit...");
                Console.ReadKey();*/

            }
        }
    }
}
