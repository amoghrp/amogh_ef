﻿-- Question 1: How many accidents have occurred in urban areas versus rural areas?
select area, count(*) as "total_accident" from accident group by area;

--QuesƟon 2: Which day of the week has the highest number of accidents?
select Day,count(*) as 'total_accident' from accident group by day order by total_accident desc;

--QuesƟon 3: What is the average age of vehicles involved in accidents based on their type?select VehicleType,count(*) as total_accs,avg(AgeVehicle) from vehicle group by VehicleType;--QuesƟon 4: Can we idenƟfy any trends in accidents based on the age of vehicles involved?select
    C.Group_Name, count(*),avg(AgeVehicle)
from vehicle
    outer apply
    (
        select
            case
                when AgeVehicle >10 or AgeVehicle is NULL then 'Old'
				when AgeVehicle >5 and AgeVehicle<=10 then 'Regular'
				when AgeVehicle <=5 then 'New'
            end as Group_Name
    ) as C
group by C.Group_Name;--QuesƟon 5: Are there any specific weather condiƟons that contribute to severe accidents?select WeatherConditions,count(*) as "Total accidents" from accident group by WeatherConditions;--orselect WeatherConditions, count(*) as 'Total Accidents' from accident 
   WHERE Severity='Fatal'
	 GROUP BY WeatherConditions 
	   ORDER BY 'Total Accidents' desc;--QuesƟon 6: Do accidents oŌen involve impacts on the leŌ-hand side of vehicles?
select LeftHand , count(*) from vehicle group by LeftHand having LeftHand is not NULL;
--QuesƟon 7: Are there any relaƟonships between journey purposes and the severity of accidents?
--select JourneyPurpose,count(*) as "total accidents" from vehicle group by JourneyPurpose;
select JourneyPurpose,count(JourneyPurpose) as total_accident,(case
when count(*) <=1000 then 'Low'
when count(*) >1000 and count(*)<=10000 then 'Moderate'
when  count(*) >10000 then 'High' end) as Level
from vehicle
group by JourneyPurpose
order by total_accident desc

--QuesƟon 8: Calculate the average age of vehicles involved in accidents , considering Day light and 
--point of impact:
select a.LightConditions,v.PointImpact,avg(v.AgeVehicle) as "Average Vehicle Year" from accident as a
join vehicle as v 
on a.AccidentIndex=v.AccidentIndex 
group by a.LightConditions,v.PointImpact
