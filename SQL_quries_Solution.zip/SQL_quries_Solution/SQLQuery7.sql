-- Create the 'dept' table
CREATE TABLE dept (
    deptno INT PRIMARY KEY,
    dname VARCHAR(50),
    loc VARCHAR(50)
);

-- Insert sample data into the 'dept' table
INSERT INTO dept (deptno, dname, loc)
VALUES
    (10, 'HR', 'New York'),
    (20, 'IT', 'San Francisco'),
    (30, 'Sales', 'Los Angeles'),
    (40, 'Marketing', 'Chicago');

-- Create the 'salgrade' table
CREATE TABLE salgrade (
    grade INT PRIMARY KEY,
    losal INT,
    hisal INT
);


-- Insert sample data into the 'salgrade' table
INSERT INTO salgrade (grade, losal, hisal)
VALUES
    (1, 1000, 2000),
    (2, 2001, 3000),
    (3, 3001, 4000),
    (4, 4001, 5000),
    (5, 5001, 6000);

-- Create the 'emp' table
CREATE TABLE emp (
    empno INT PRIMARY KEY,
    ename VARCHAR(50),
    job VARCHAR(50),
    mgr INT,
    hiredate DATE,
    sal INT,
    comm INT,
    deptno INT,
    FOREIGN KEY (deptno) REFERENCES dept(deptno)
);

-- Insert sample data into the 'emp' table
INSERT INTO emp (empno, ename, job, mgr, hiredate, sal, comm, deptno)
VALUES
    (7369, 'Smith', 'Clerk', 7902, '1980-12-17', 800, NULL, 20),
    (7499, 'Allen', 'Salesman', 7698, '1981-02-20', 1600, 300, 30),
    (7521, 'Ward', 'Salesman', 7698, '1981-02-22', 1250, 500, 30),
    (7566, 'Jones', 'Manager', 7839, '1981-04-02', 2975, NULL, 20),
    (7654, 'Martin', 'Salesman', 7698, '1981-09-28', 1250, 1400, 30),
    (7698, 'Blake', 'Manager', 7839, '1981-05-01', 2850, NULL, 30),
    (7782, 'Clark', 'Manager', 7839, '1981-06-09', 2450, NULL, 10),
    (7788, 'Scott', 'Analyst', 7566, '1982-12-09', 3000, NULL, 20),
    (7839, 'King', 'President', NULL, '1981-11-17', 5000, NULL, 10),
    (7844, 'Turner', 'Salesman', 7698, '1981-09-08', 1500, 0, 30),
    (7876, 'Adams', 'Clerk', 7788, '1983-01-12', 1100, NULL, 20);

-- Commit the changes
COMMIT;

--------BASIC SQL LABS ----------------


--Here are 25 SQL select query exercises based on the `emp` and 'dept' table for practice:

--1. Retrieve all columns for all employees.
select * from emp;
--2. Retrieve the names and job titles of all employees.
select ename,job from emp;
--3. Retrieve the unique department numbers from the `emp` table.
select distinct deptno  from emp;
--4. Retrieve the names of employees hired after January 1, 1982.
select ename from emp where hiredate > '1982-01-01';
--5. Retrieve the names of employees whose job title is 'Manager.'
select ename from emp where job = 'Manager';
--6. Retrieve the names and salaries of employees earning more than 2500.
select ename,sal from emp where sal > 2500;
--7. Retrieve the names, job titles, and salaries of employees hired in department 20.
select ename,job,sal from emp where deptno=20;
--8. Retrieve the names of employees who don't have a manager (`mgr` is NULL).
select ename from emp where mgr is NULL;
--9. Retrieve the average salary of all employees.
select AVG(sal) from emp;
--10. Retrieve the highest salary from the `emp` table.
select MAX(sal) from emp;
--11. Retrieve the names of employees who earn the highest salary.
select ename,sal from emp where sal =(select MAX(sal) from emp);
--12. Retrieve the names and hire dates of employees hired in 1981.
select ename, hiredate from emp where hiredate >= '1981-01-01' and hiredate <= '1981-12-31';
--13. Retrieve the names of employees who work in departments located in 'New York.'
select e.ename,loc from emp e,dept d where d.loc = 'New York' and e.deptno = d.deptno;
--14. Retrieve the names of employees who work in departments with a location containing 'Los Angeles.'
select e.ename from emp e,dept d where d.loc = 'Los Angeles' and e.deptno = d.deptno;
--15. Retrieve the names of employees whose salary is in the range of 2000 to 3000.
select ename from emp where sal >= 2000 and sal <=3000;
--16. Retrieve the names of employees in department 30 with a salary greater than 1500.
select ename from emp where deptno = 30 and sal > 1500;
--17. Retrieve the names of employees in department 10 or department 20.
select ename from emp where deptno =10 or deptno = 20;
--18. Retrieve the names of employees who have a commission (`comm`) value.
select ename from emp where comm is not null;
--19. Retrieve the names of employees whose names start with the letter 'S.'
select ename from emp where ename like 'S%';
--20. Retrieve the names of employees whose names end with the letter 'E.'
select ename from emp where ename like '%E';
--21. Retrieve the names of employees whose names contain the letter 'A.'
select ename from emp where ename like '%A%';
--22. Retrieve the names of employees in department 20 who have 'Clerk' in their job title.
select ename from emp where deptno =20 and job = 'Clerk';
--23. Retrieve the names of employees who work in the same department as 'Jones' (use a subquery).
select ename from emp where deptno = (select deptno from emp where ename = 'Jones');
--24. Retrieve the names and salaries of employees sorted by salary in ascending order.
select ename ,sal from emp order by sal asc;
--25. Retrieve the names of employees with the same job title as 'King' but different employee numbers.
select ename,empno from emp where job = (select job from emp where ename = 'King') and empno != (select empno from emp where ename = 'King');

--These exercises cover a variety of SQL query scenarios that you can use to practice your SQL skills with the `emp` table. You can modify and expand upon these exercises to further challenge yourself.



-- retrieve employee details with department names
select * from emp;
select *from dept;

select emp.ename, dept.dname 
from emp join dept on emp.deptno = dept.deptno;

-- 2 retrieve employee details with job titles

--**Lab 3: Retrieve Department Names with Locations**

--Lab 4: Retrieve Employee Names and Salaries with Department Names
select emp.ename, dept.dname,dept.deptno,emp.sal
from emp right join dept on emp.deptno = dept.deptno;
-- Retrieve Employee Names, Job Titles, and Salary Grades
select e.ename , e.job, s.grade 
from emp as e join salgrade as s on e.sal between s.losal and s.hisal;

--Lab 6: Retrieve Employee Names with Manager Names**
-- self join 
select e.ename as employee , m.ename as manager
from emp as e, emp as m
where e.mgr = m.empno;
--or
select e.ename as employee,m.ename as manager
from emp e join emp m
on e.mgr = m.empno;

--**Lab 7: Retrieve Employee Names with Commission Amounts**
select ename , comm from emp where comm is not null and comm > 0;
--**Lab 8: Retrieve Department Names with Average Salaries**
select d.dname,avg(e.sal) as avarage_salary
from emp e join dept d on e.deptno = d.deptno
group by d.dname
having avg(e.sal) >= 2000;


--**Lab 9: Retrieve Employee Names with Department Names and Locations**
--Write a SQL query to retrieve the names of employees along with their department names and locations.
select e.ename,d.dname,d.loc from emp e , dept d where e.deptno = d.deptno;
--**Lab 10: Retrieve Employee Names with Job Titles and Salary Ranges**
select e.ename , e.job, sg.grade
from emp e, dept d, salgrade sg
where e.sal >= sg.losal and e.sal <= sg.hisal;
exec sp_dept_avg_sal;

