
CREATE PROCEDURE sp_dept_avg_sal
AS
BEGIN
	select d.dname,avg(e.sal) as avarage_salary
	from emp e join dept d on e.deptno = d.deptno
	group by d.dname
	having avg(e.sal) >= 2000;
END
GO
