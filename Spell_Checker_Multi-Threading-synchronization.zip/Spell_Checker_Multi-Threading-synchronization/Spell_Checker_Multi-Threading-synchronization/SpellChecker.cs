﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Spell_Checker_Multi_Threading_synchronization
{
    public class SpellChecker
    {
        public LevenshteinDistance lsd = new LevenshteinDistance();
        public DictionaryFileLoader dfl = new DictionaryFileLoader();
        string dictionaryFile = "dictionary_file.txt"; // give file path later
        public static List<string> dictionary_words = new List<string>();
        public List<string>  Check(string str)
        {
           
            List<string> output_suggested_words = new List<string>();
            if (dictionary_words.Contains(str))
            {
                // if the word exists in dictionary then it is spelled correctly
                return null;
            }
            else
            {
                Dictionary<string, int> wordDistances = new Dictionary<string, int>();
                /* */
                /*foreach(string word in dictionary_words)*/
                Parallel.ForEach(dictionary_words, word => {
                    
                    int distance = lsd.CalculateDistance(str, word);
                    // if (str.StartsWith((word[0]).ToString()) &&distance <=5)
                    if (distance <=5)
                    lock (this) { wordDistances.Add(word, distance); }
                    

                });
                

                var nearest_words = wordDistances.OrderBy(x => x.Value).Take(10).ToList();
                
                int only_ten = 0;
                    foreach(var pair in nearest_words)
                    {
                    only_ten++;
                    if (only_ten > 10) break;
                    output_suggested_words.Add(pair.Key);
                    }
                return output_suggested_words;

            }
            //return null;
        }
    }
}
