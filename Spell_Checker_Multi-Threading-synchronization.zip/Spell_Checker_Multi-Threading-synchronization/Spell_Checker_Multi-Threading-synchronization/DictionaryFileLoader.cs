﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Spell_Checker_Multi_Threading_synchronization
{
    public class DictionaryFileLoader
    {
            public static List<string> Load(string dictFile)
            {
                List<string> ls = new List<string>();

                if (File.Exists(dictFile))
                {
                    try
                    {
                        using (StreamReader reader = new StreamReader(dictFile))
                        {
                            string line;
                            while ((line = reader.ReadLine()) != null)
                            {
                                string[] strings = line.Split(' ');
                                foreach (string s in strings)
                                {
                                    ls.Add(s);
                                }
                            }

                        }
                        return ls;
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.GetType().Name);
                    }
                }
                else
                {
                    Console.WriteLine("dictionary file not found");
                }

                return null;
            }
    }
}
