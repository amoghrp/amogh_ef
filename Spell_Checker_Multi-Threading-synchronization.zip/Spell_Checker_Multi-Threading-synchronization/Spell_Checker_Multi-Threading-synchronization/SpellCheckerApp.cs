﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace Spell_Checker_Multi_Threading_synchronization
{
    public class SpellCheckerApp
    {
       /* public string inputFile { get; set; } = "myinputfile.txt";
        public string outputFile { get; set; } = "outputfile.txt";*/

        public SpellChecker sck { get; set; } = new SpellChecker();

        public InputFileLoader ifl { get; set; } = new InputFileLoader();
        public static List<string> los = new List<string>();
        public void StartSpellCheck(string inputfile, string outputfile)
        {
            
            if (los != null)
            {
                /*foreach (string s in los)*/
                Parallel.ForEach(los, s =>  
                {
                    List<string> correct_sugessted_words = sck.Check(s);
                    if (correct_sugessted_words != null) 
                    {
                         
                        try
                        {
                            lock (this) {
                                using (StreamWriter writer = new StreamWriter(outputfile, true))
                                {
                               
                                    writer.WriteLine($"for word -- {s} -- suggested words are :");
                                    foreach (string csw in correct_sugessted_words)
                                    {
                                        writer.WriteLine(csw);
                                    }
                                
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                            Console.WriteLine("exception occured in start spell check \n");
                        }
                        finally
                        {
                            //
                        }
                    }
                   
                    
                });

            }
            else
            {
                Console.WriteLine("file cound'nt be loaded in input file loader");
            }
        }
    }
}
