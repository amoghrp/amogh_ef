﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Spell_Checker_Multi_Threading_synchronization
{
    public class InputFileLoader
    {
        
        public static List<string> Load(string inputfile)
        {
            List<string> ls = new List<string>();

            if(File.Exists(inputfile))
            {
                try
                {
                    using (StreamReader reader = new StreamReader(inputfile))
                    {
                        string line;
                        while((line = reader.ReadLine()) != null)
                        {
                            string[] strings = line.Split(' ');
                            foreach(string s in strings)
                            {
                                ls.Add(s);
                            }
                        }
                       
                    }
                    return ls;
                }
                catch(Exception e)
                {
                    Console.WriteLine(e.GetType().Name);
                }
            }
            else
            {
                Console.WriteLine("input file not found");
            }

            return null;
        }
    }
}
