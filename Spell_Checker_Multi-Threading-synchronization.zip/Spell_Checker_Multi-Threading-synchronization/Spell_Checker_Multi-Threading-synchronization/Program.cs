﻿using System;
using System.Diagnostics;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Spell_Checker_Multi_Threading_synchronization
{
    public class Program
    {
        static void Main(string[] args)
        {
            Stopwatch sw = Stopwatch.StartNew();

            /*SpellChecker.dictionary_words = DictionaryFileLoader.Load("dictionary_file.txt");
            SpellCheckerApp.los = InputFileLoader.Load("myinputfile.txt");
            
            this above file can be loaded parallelly and stored even much before using 
            using parallel invoke
             */
            Parallel.Invoke(() => { SpellChecker.dictionary_words = DictionaryFileLoader.Load("dictionary_file.txt"); } , () => { SpellCheckerApp.los = InputFileLoader.Load("myinputfile.txt"); } );
            SpellCheckerApp sca = new SpellCheckerApp();
            sca.StartSpellCheck("myinputfile.txt", "outputfile.txt");
            Console.WriteLine("time = "+sw.ElapsedMilliseconds);

        }
    }
}
