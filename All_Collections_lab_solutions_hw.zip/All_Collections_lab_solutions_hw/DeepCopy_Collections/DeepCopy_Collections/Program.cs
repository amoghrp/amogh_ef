﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeepCopy_Collections
{

    public static class CustomExtensions
    {
        private static readonly Random random = new Random();

        
       public static List<T> DeepCopy<T>(this List<T> list) where T : new()
        {
            List<T> newList = new List<T>();
            foreach (T item in list)
            {
                if (item == null)
                {
                    newList.Add(item); // Add null as is
                }
                else
                {
                    // Create a new instance of the item's type and copy its properties
                    T newItem = new T();
                    DeepCopyHelper.CopyProperties(item, newItem);
                    newList.Add(newItem);
                }
            }
            return newList;
        }

        // Helper class to perform deep copy by copying properties
        private static class DeepCopyHelper
        {
            public static void CopyProperties<T>(T source, T destination)
            {
                foreach (var property in typeof(T).GetProperties())
                {
                    if (property.CanRead && property.CanWrite)
                    {
                        property.SetValue(destination, property.GetValue(source));
                    }
                }
            }
        }
    }



class Program
    {
        static void Main(string[] args)
        {
            // Example usage of Shuffle extension method
            List<int> numbers = new List<int> { 1, 2, 3, 4, 5 };
           
            Console.WriteLine(string.Join(", ", numbers)); // Output will be a shuffled version of the list

            // Example usage of DeepCopy extension method
            List<Person> originalList = new List<Person>
        {
            new Person { Name = "Alice", Age = 30 },
            new Person { Name = "Bob", Age = 25 }
        };
            List<Person> copiedList = originalList.DeepCopy();
            foreach (var person in copiedList)
            {
                Console.WriteLine($"Name: {person.Name}, Age: {person.Age}");
            }
        }
    }

    class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }


}

/*
 using System;
using System.Collections.Generic;

 */
