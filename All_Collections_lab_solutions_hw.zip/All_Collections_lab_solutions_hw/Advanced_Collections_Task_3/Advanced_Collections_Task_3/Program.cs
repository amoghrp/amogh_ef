﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Advanced_Collections_Task_3
{
    internal class Program
    {
        static void Main(string[] args)
        {

            List<int> list = new List<int>();
            list.Add(1);
            list.Add(2);
            list.Add(3);
            list.Add(4);
            list.Add(5);
            list.Add(6);
            list.Add(7);
            list.Add(8);
            list.Add(9);
            list.Add(10);
            Console.WriteLine("before shuffling");
            foreach (int x in list)
            {
                Console.Write(x + " ");
            }
            Console.WriteLine();
            Console.WriteLine("after shuffling");
            //////////////shuffler//////////////////// 
            list.Shuffle(); 
            foreach(int x in list)
            {
                Console.Write(x + " ");
            }
            Console.WriteLine();
            //////////// deep copy ///////////
            // Example usage of DeepCopy extension method
            List<Person> originalList = new List<Person>
        {
            new Person { Name = "Alice", Age = 30 },
            new Person { Name = "Bob", Age = 25 }
        };
            List<Person> copiedList = originalList.DeepCopy();
            Console.WriteLine("displaying copied list");
            foreach (var person in copiedList)
            {
                Console.WriteLine($"Name: {person.Name}, Age: {person.Age}");
            }
        }
    }
    public class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
    public static class CollectionExtensions
    {
        public static Random r = new Random();

        public static void Shuffle<T>(this List<T> l)
        {
            for(int i=l.Count-1; i>=0;i--)
            {
                int j = r.Next(0,i);
                T t = l[j];
                l[j] = l[i];
                l[i] = t;
            }
        }
        public static List<T> DeepCopy<T>(this List<T> list) where T : new()
        {
            List<T> newList = new List<T>();
            foreach (T item in list)
            {
                if (item == null)
                {
                    newList.Add(item); // Add null as is
                }
                else
                {
                    // Create a new instance of the item's type and copy its properties
                    T newItem = new T();
                    DeepCopyHelper.CopyProperties(item, newItem);
                    newList.Add(newItem);
                }
            }
            return newList;
        }

        // Helper class to perform deep copy by copying properties
        private static class DeepCopyHelper
        {
            public static void CopyProperties<T>(T source, T destination)
            {
                foreach (var property in typeof(T).GetProperties())
                {
                    if (property.CanRead && property.CanWrite)
                    {
                        property.SetValue(destination, property.GetValue(source));
                    }
                }
            }
        }
    }
}
