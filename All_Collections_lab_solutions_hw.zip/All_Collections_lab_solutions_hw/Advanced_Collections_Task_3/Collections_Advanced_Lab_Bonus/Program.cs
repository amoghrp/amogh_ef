﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collections_Advanced_Lab_Bonus
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random r = new Random();
            List<int> intList = new List<int>();

            for(int i = 0; i <= 8; i++)
            {
                intList.Add(r.Next(0,100));
            }
            List<string> stringList = MyConvert<int, string>(intList, ConvertLogicFunc);
            Console.WriteLine("printing the list of string after conversion from int");
            foreach(string str in stringList)
            {
                Console.Write(str+"  ");
            }
            Console.WriteLine();
        }
         
        public static List<TDestination> MyConvert<TSource, TDestination>(IEnumerable<TSource> source, Func<TSource, TDestination> converter)
        {
            List<TDestination> dest = new List<TDestination>();
            foreach (TSource sourceItem in source)
            {
               
                dest.Add(converter(sourceItem));
            }
            return dest;

        }
        public static string ConvertLogicFunc(int a)
        {
            
            return a.ToString();
        }


    }
}
