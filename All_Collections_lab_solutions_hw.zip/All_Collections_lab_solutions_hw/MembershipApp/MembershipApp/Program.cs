﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MembershipApp
{
    internal class Program
    {
        public static void Main(string [] args)
        {

        }
    }
    public class Company
    {
        public string Name { get; set; }
        public List<Customer> CustomersList = new List<Customer>(); 
        public Company() { }
        public void SetName(string name) { Name = name; }
        public string GetName() { return Name; }
        public void AddCustomer(Customer customer) {  CustomersList.Add(customer); }
        public List <Customer> GetCustomersList() {  return CustomersList; }
    }
    public class Customer
    {
        public string CustId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public Customer() { }
        public string GetCustId() { return CustId; }
        public void SetCustId(string custId) {  CustId = custId; }
        public string GetName() { return Name; }
        public void SetName() { Name = Name; }
        public string GetEmail() { return Email; }
        public void SetEmail(string email) {  Email = email; }



    }
    public class RegCustomer : Customer
    {
        public string DtReg { get; set; }
        public MemberShip membership { get; set; }
        public RegCustomer() { }
        public string DateReg() { return DtReg; }
        public void SetDateReg(string dateReg) { DtReg = dateReg; }
        public void SetMembership(MemberShip membership) { this.membership = membership; }
        public MemberShip GetMemberShip() { return membership; }
        public string GetTypeOfMemberShip()
        {
            return membership.TypeOfMembership;
            //return typeof(MemberShip).Name;
        }
        public double GetDiscount()
        {
            // returns percentage of discount
            return membership.Discount;
        }
        public double GetFees()
        {
            return membership.fees;
        }
    }
    public class MemberShip
    {
        public string TypeOfMembership { get; set; }
        public double Discount { get; set; }
        public double fees { get; set; }
        ~MemberShip() 
        {
            
        }
        public string GetTypeOfMembership() { return TypeOfMembership; }
        public void SetTypeOfMembership(string typeOfMembership) { TypeOfMembership = typeOfMembership; }

        public double GetDiscount() { return 10; }
        public void setDiscount(double discount) {  Discount = discount; }
        public double GetFees() {  return 100; }
        public void SetFees(double fees) { this.fees = fees; }

    }
    public sealed class MemberShipFactory
    {
        public Dictionary<string,MemberShip> pool = new Dictionary<string,MemberShip>();
        static MemberShipFactory instance = null;
        private MemberShipFactory() { }
        public static MemberShipFactory Instance
        {
            get
            {
                if(instance == null)
                {
                    instance = new MemberShipFactory();
                }
                return instance;
            }
        }
        public List<MemberShip> MemeberShipList = new List<MemberShip>();
        ~MemberShipFactory() { }
        public MemberShip CreateMemberShip(string typeofmembership , double fees, double discount)
        {
            MemberShip ms = new MemberShip();
            ms.fees = fees;
            ms.TypeOfMembership = typeofmembership;
            ms.Discount = discount;
            return ms;
        }
        public MemberShip CreateMem(string typeofmem) { 
            MemberShip mes = new MemberShip();
            mes.TypeOfMembership = typeofmem;
            return mes;
        }
        public static MemberShipFactory GetInstance()
        {
            return instance;
        }

    }
}