﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collections_Generic_Assessments_1_28_02_24
{
    internal class Program
    {
        public static List<ClsPerson> l = new List<ClsPerson>();
       
        static void Main(string[] args)
        {
            Console.WriteLine("assig 1 soln :");

            A1();
            Console.WriteLine("assig 2 soln :");
            A2();
            Console.WriteLine("assig 3 soln :");
            A3();
            Console.WriteLine("assig 4 soln :");
            A4();
            Console.WriteLine("assig 5 soln :");
            A5();
            Console.WriteLine("assig 6 soln :");
            A6();


        }

        public static void A6()
        {

            ClsPerson2 cl = new ClsPerson2();
            cl.Name = "John";
            cl.Age = 16;
            cl.PlaceOfBirth = "Chennai";

            ClsPerson2 cl2 = new ClsPerson2();
            cl2.Name = "Smita";
            cl2.Age = 22;
            cl2.PlaceOfBirth = "Delhi";

            ClsPerson2 cl3 = new ClsPerson2();
            cl3.Name = "Vincet";
            cl3.Age = 25;
            cl3.PlaceOfBirth = "Banglore";

            ClsPerson2 cl4 = new ClsPerson2();
            cl4.Name = "Jyothi";
            cl4.Age = 10;
            cl4.PlaceOfBirth = "Banglore";

            SortedList sl = new SortedList();
            sl.Add("John",cl);
            sl.Add("Smita",cl2);
            sl.Add("Vincet",cl3);
            sl.Add("Jyothi",cl4);
            
            //sl.Add("Jyothi",cl4);

            ClsPerson2 n = new ClsPerson2();
            n.Age = 10;
            sl.Add("null",n);
            Console.WriteLine();
            foreach (var key in sl.Keys)
            {
                Console.Write($"name = {((ClsPerson2)sl[key]).Name}  age = {((ClsPerson2)sl[key]).Age}  ");
                Console.WriteLine($"can vote =  {((ClsPerson2)sl[key]).CanVote()}");

            }

        }

        public static void A5()
        {
            ClsPerson2 cl = new ClsPerson2();
            cl.Name = "John";
            cl.Age = 16;
            cl.PlaceOfBirth = "Chennai";

            ClsPerson2 cl2 = new ClsPerson2();
            cl2.Name = "Smita";
            cl2.Age = 22;
            cl2.PlaceOfBirth = "Delhi";

            ClsPerson2 cl3 = new ClsPerson2();
            cl3.Name = "Vincet";
            cl3.Age = 25;
            cl3.PlaceOfBirth = "Banglore";

            ClsPerson2 cl4 = new ClsPerson2();
            cl4.Name = "Jyothi";
            cl4.Age = 10;
            cl4.PlaceOfBirth = "Banglore";

            Hashtable ht = new Hashtable();
            ht.Add("John",cl);
            ht.Add("Smita", cl2);
            ht.Add("Vincet",cl3);
            ht.Add("Jyothi",cl4);

            //ht.Add("Jyothi",cl4);
            ClsPerson2 cl6 = new ClsPerson2();
            cl6.Age = 10;
            ht.Add("ABC",cl6);

            foreach(var key in ht.Keys)
            {
                Console.WriteLine();
                Console.Write($" name =  { ((ClsPerson2)(ht[key])).Name }"+ $" {((ClsPerson2)(ht[key])).Age} "  + "  ");
                if (((ClsPerson2)ht[key]).CanVote())
                Console.Write($" can vote ");
                else
                    Console.WriteLine($" cannot vote ");
            }




        }

        public static void A4()
        {
            Queue<string> qs = new Queue<string>();
            qs.Enqueue("string1");
            qs.Enqueue("string2");
            qs.Enqueue("string4");
            qs.Enqueue("string5");
            Console.WriteLine();
            while (qs.Count > 0)
            {
                Console.Write(qs.Dequeue() + " ");
            }
            Console.WriteLine();
            for(int i = 0; i < 5; i++)
            {
                qs.Enqueue("string" + (i+1));
            }
            Console.WriteLine();
            while (qs.Count > 0)
            {
                Console.Write(qs.Dequeue() + " ");
            }
            Console.WriteLine();

        }

        public static void A3()
        {
            Stack<string> s = new Stack<string>();
            s.Push("string1");
            s.Push("string2");
           
            s.Push("string4");
            s.Push("string5");

            while (s.Count > 0)
            {
                Console.Write(s.Pop() + " ");
            }
            s.Push("string1");
            s.Push("string2");
            
            s.Push("string4");
            s.Push("string5");

            while (s.Count > 0)
            {
                Console.Write(s.Pop() + " ");
            }

            s.Pop();
            s.Pop();
            s.Push("string3");
            s.Push("string4");
            s.Push("string5");

            while (s.Count > 0)
            {
                Console.Write(s.Pop() + " ");
            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine(s.Peek());

        }


        static int x = 0;
        public static void disl(List<ClsPerson> l,int size)
        {
            if (x < size)
            {
                Console.Write(l[x].Name + " ");
                x++;
                disl(l, size);
            }
            
        }
        public static void A2()
        {
            string choice;
            Console.WriteLine("assig 2");
            do
            {
                Console.WriteLine("enter a name of a person");
                string n = Console.ReadLine();
                ClsPerson p = new ClsPerson();
                p.Name = n;
                l.Add(p);
                Console.WriteLine("do you wanna continue ?? Y/N");
                choice = Console.ReadLine();

            } while (choice == "y" || choice == "Y");

            Console.WriteLine("displaying persons ");
            
            foreach (ClsPerson p in l)
            {
                Console.Write(p.Name + " ");
            }
            Console.WriteLine();
            /// we can display the persons list using many methods like
            /// we can use classic for loop
            
            int i = 0;
            for( i=0;i< l.Count;i++)
            {
                Console.Write(l[i].Name + " ");
            }
            Console.WriteLine();
            /// while loop
            i = 0;
            while (i<l.Count)
            {
                
                Console.Write(l[i].Name + " ");
                i++;
            }
            Console.WriteLine();
            i = 0;
            /// do while loop
            do
            {
                if(i<l.Count)
                    Console.Write(l[i].Name + " ");
                i++;
            } while (i<l.Count);

            Console.WriteLine();

            disl(l,l.Count);
            Console.WriteLine();
            /// recursion
        }

        public static void A1()
        {
            bool acceptFlag = true;
            List<int> myints = new List<int>();
            while (acceptFlag)
            {

                Console.WriteLine("enter some integer");
                int i = int.Parse(Console.ReadLine());
                myints.Add(i);

                Console.WriteLine("do you want to continu  ? Y/N ");
                string accept = Console.ReadLine().ToUpper();
                if (accept == "y" || accept == "Y")
                {
                    acceptFlag = true;
                }
                else
                {
                    acceptFlag = false;
                }
            }
            if(myints.Count ==0) { Environment.Exit(1); }   
            Console.WriteLine($"number of integers in the list {myints.Count}");
            int avg = (int)myints.Average();
            Console.WriteLine($"average = {avg}");
            myints.Insert((myints.Count / 2), avg);

            display(myints);
            myints.RemoveAt(2);
            display(myints);
            myints.Remove(avg);

            display(myints);

            // the difference between Remove and RemoveAt is Remove will remove the first occurance of 
            /// an element 
            /// whereas RemoveAt will remove the element from specific index

        }
        public static void display(List<int> l)
        {
            foreach(int i in l)
            {
                Console.Write(i + " ");
            }
            Console.WriteLine();
        }

    }

    public class ClsPerson2
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string PlaceOfBirth { get; set; }
        public ClsPerson2() {
            Name = "A";
            Age = 18;
            PlaceOfBirth = "abc";

        }
        public bool CanVote()
        {
            return Age >= 18;
        }

    }

    public class ClsPerson
    {
        public string Name { get; set; }

    }
}
