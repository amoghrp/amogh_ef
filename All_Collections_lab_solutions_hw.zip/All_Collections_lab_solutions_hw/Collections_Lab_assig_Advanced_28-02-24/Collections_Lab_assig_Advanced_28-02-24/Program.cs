﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collections_Lab_assig_Advanced_28_02_24
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Person> l = new List<Person>();
            for(int i = 0; i < 10; i++)
            {
                Person p = new Person();
                p.Name = "name" + i;
                p.Age = i + 11;
                l.Add(p);
            }

            foreach (Person p in l)
            {
                Console.WriteLine(p.Name + " " + p.Age);
            }
            Console.WriteLine();



             l.Sort(new PersonDescendingComparer());
            Console.WriteLine("after sorting");
            foreach (Person p in l)
            {
                Console.WriteLine(p.Name + " " + p.Age);
            }
            /*
            Console.WriteLine();
            SortingComparer(ref l);

            foreach (Person p in l)
            {
                Console.WriteLine(p.Name + " " + p.Age);
            }*/



            Human h1 = new Human() { Id = 1,Name = "abc",Age = 23};
            Human hh = new Human() { Id = 1,Name = "www" , Age = 34};
            Human h2 = new Human() { Id = 2, Name = "def", Age = 22};
            Human h3 = new Human() { Id = 3, Name = "aaa", Age = 33 };
            Human h4 = new Human() { Id = 4, Name = "erwe", Age = 44 };

            List<Human> hl = new List<Human>();
            hl.Add(h1);
            hl.Add(h2);
            hl.Add(h3);
            hl.Add(h4);
            // conveting to dictionary using linq
            Console.WriteLine("// conveting to dictionary using linq");
            var dd = hl.ToDictionary(x=>x.Id,x=>x);

            foreach (var s in dd)
            {
                Console.WriteLine($"{s.Key}  {s.Value}");
            }

            Console.WriteLine("back to list using linq");
            List<Human> nl = dd.Values.Where(x=> x.Age > 30 ).ToList();
            

            foreach (var s in nl)
            {
                Console.Write(s.Name + " ");
            }

            Console.WriteLine();
            Console.WriteLine("using custom specific function");

            Dictionary<int,Person> d = ConvertToDictionary(ref l);
            foreach(int k in d.Keys)
            {
                Console.WriteLine($"{d[k].Name}  {d[k].Age}");
            }
            Console.WriteLine("back to list");
            
            l = ConvertBackToList(ref d);
            
            foreach (Person p in l)
            {
                Console.WriteLine(p.Name + " " + p.Age);
            }

        }

        public static List<Person> ConvertBackToList(ref Dictionary<int,Person> d)
        {
            List<Person> p = new List<Person>();
            foreach(int k in d.Keys)
            {
                p.Add(d[k]);
            }
            return p;
        }
        public static Dictionary<int, Person> ConvertToDictionary(ref List<Person> l)
        {
            Console.WriteLine("converting to dictionary");
            Dictionary<int,Person> d = new Dictionary<int,Person>();
            for(int i = 0; i < l.Count; i++)
            {
                d.Add(i, l[i]);
            }
            return d;
        }
        public static void SortingComparer(ref List<Person> l)
        {
            for(int i = 1; i < l.Count; i++)
            {
                Person key_p = l[i];
                int j = i - 1;

                while(j>=0 && l[j].Age < key_p.Age)
                {
                    l[j+1] = l[j];
                    j--;
                }
                l[j + 1] = key_p;
            }
        }
    }
   
    public class PersonDescendingComparer : IComparer<Person>
    {
        public  int Compare(Person x, Person y)
        {
            return y.Age.CompareTo(x.Age);
        }
    }

    public class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }

    }
    public class Human
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
    }
}
