﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bonus_Collecions_lab_2
{

    /*
    
    Bonus challenge
    Implement a custom generic Collection by defining a class MyCollection<T> that
    implements the IEnumerable<T> interface . Provide methods for adding , removing and iterating 
    over items in your custom collection 
    Add sorting functionality to your cusotm collection  without using the built in sort methods

    */

    internal class Program
    {
        static void Main(string[] args)
        {
            MyCollectionList<int> myl = new MyCollectionList<int>();
           
            /*l.Add(23);
            l.Add(12);
            l.Add(89);
            l.Add(45);
            l.Add(34);
            l.Add(90);
            l.Add(1);
            l.Add(63);
*/
            Random r = new Random();
            for(int i=0;i<=7; i++)
            {
                myl.Add((int)r.Next(0,100));
            }

            Console.WriteLine();
            foreach (int item in myl)
            {
                Console.Write(item + "\t");
            }
            Console.WriteLine();
            Console.WriteLine("item at index 4 is  "+myl.Get(4));
            Console.WriteLine();
            Console.WriteLine("removing from id = 4");
            myl.RemoveAt(4);
            foreach (int item in myl)
            {
                Console.Write(item + "\t");
            }
            Console.WriteLine();
            Console.WriteLine("enter the number to remove");
            int y = Convert.ToInt32(Console.ReadLine());
            myl.Remove(y);
            foreach (int item in myl)
            {
                Console.Write(item + "\t");
            }
            Console.WriteLine();
            Console.WriteLine("sorting -----");
            myl.Sort();
            foreach (int item in myl)
            {
                Console.Write(item + "\t");
            }
            Console.WriteLine();
            Console.WriteLine();
        }
    }
    public class MyCollectionList<T> : IEnumerable<T> where T : IComparable<T>
    {
        /////////////// interface extension required code that helps in iterating over the items.
        public IEnumerator<T> GetEnumerator()
        {
            return items.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
        ///////////////////////// our code 

        private List<T> items ;
        public int Count { get; private set; } 
        public MyCollectionList()
        {
            this.items = new List<T>();
            Count = items.Count;
        }
        public void Add(T obj)
        {
            items.Add(obj);
            Count = items.Count;
        }
        public T Get(int id)
        {

            return items[id];
        }
        public void RemoveAt(int id)
        {
             items.RemoveAt(id);
            Count = items.Count;
        }
        public bool Remove(T obj)
        {
            bool x = items.Remove(obj);
            Count = items.Count;
            return x;
        }
        public void Sort()
        {
            for(int i=1; i < items.Count; i++)
            {
                int j = i - 1;
                T key = items[i];

                while(j>=0 && items[j].CompareTo(items[j+1]) >0 )
                {
                    items[j+1] = items[j];
                    j--;
                }
                items[j + 1] = key;
            }
        }

       
    }
}