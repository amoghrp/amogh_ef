﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collections_Lab_2_hwassig
{
   

    internal class Program
    {
        static void Main(string[] args)
        {
            //Task1();
            //Task2();
            //Task3();

            // bonus challenge bonus challenge done in another file 
        }







        public static void Task3()
        {
            Queue<string> q = null;
            PopulateQ(ref q);
            DisplayQ(ref q);
            QueueOps(ref q);

            Console.WriteLine();

            Stack<string> s = null;
            PopulateStack(ref s);
            DisplayStack(ref s);
            StackOps(ref s);

        }

        public static void DisplayStack(ref Stack<string> s)
        {
            Console.WriteLine("displaying stack");
            foreach (string sv in s)
            {
                Console.Write(sv + "   ");
            }
            Console.WriteLine();
        }
        public static void StackOps(ref Stack<string> s)
        {
            Console.WriteLine("pushing twice");
            s.Push("abc");
            s.Push("def");
            DisplayStack(ref s);
            Console.WriteLine("poping twice");
            s.Pop();
            s.Pop();
            DisplayStack(ref s);
            Console.WriteLine();
        }
        public static void PopulateStack(ref Stack<string> s)
        {
            s = new Stack<string>();
            for (int i = 0; i < 5; i++)
            {
                s.Push($"v{(i + 1)}");
            }
        }
        public static void QueueOps(ref Queue<string> q)
        {
            Console.WriteLine("enqueing twice");
            q.Enqueue("abc");
            q.Enqueue("def");
            DisplayQ(ref q);
            Console.WriteLine("dequeing twice");
            q.Dequeue();
            q.Dequeue();
            DisplayQ(ref q);
            Console.WriteLine();
        }
        public static void DisplayQ(ref Queue<string> q)
        {
            Console.WriteLine("displaying q");
            foreach (string s in q)
            {
                Console.Write(s + "   ");
            }
            Console.WriteLine();
        }
        public static void PopulateQ(ref Queue<string>q)
        {
            q = new Queue<string>();
            for(int i = 0;i<5;i++)
            {
                q.Enqueue($"v{(i+1)}");
            }
        }
        


        public static void Task2()
        {
            Dictionary<int, string> d = null;
            CreateAndPopulateDictionary(ref d);

            DisplayDictionary(ref d);

            UpdateName("amogh",3,ref d);

            DisplayDictionary(ref d);

            FindNameById(ref d,3);
            
            DisplayDictionary(ref d);
        }
        public static void DisplayDictionary(ref Dictionary<int,string> d)
        {

            Console.WriteLine("displaying");
            foreach (KeyValuePair<int,string> kvp in d)
            {
                Console.WriteLine($"key = {kvp.Key} value = {kvp.Value}");
            }
            foreach (int k in d.Keys)
            {
                Console.WriteLine($"key = {k} value = {d[k]}");
            }
            Console.WriteLine("----------------");
        }
        public static void UpdateName(string name , int id,ref Dictionary<int, string> d)
        {
            if (d.ContainsKey(id))
            {
                d[id] = name;
            }
            else
            {
                Console.WriteLine("the given id does not exists");
            }
        }
        public static void FindNameById( ref Dictionary<int, string> d , int id)
        {
            if (d.ContainsKey(id))
            {
                Console.WriteLine($"the name with id {id} is found and is = {d[id]}");
            }
            else
            {
                Console.WriteLine("the given id does not exists");
            }
        }
        public static void CreateAndPopulateDictionary(ref Dictionary<int,string> d)
        {
            d = new Dictionary<int, string>();
            for(int i = 0; i < 5; i++)
            {
                d[i] = ("name "+(i+1));
            }
        }





        public static void Task1()
        {
            List<string> l = null;
            CreateAndPopulateList(ref l);
            DisplayListContents(ref l);
            InsertName("amogh",3,ref l);
            Console.WriteLine("displyaing  after insertion");
            DisplayListContents(ref l);

        }
        public static void InsertName(string name , int id, ref List<string> l)
        {
            l.Insert(id, name);
        }
        public static void DisplayListContents(ref List<string> l)
        {
            Console.WriteLine("displaying");
            foreach (String name in l)
            {
                Console.Write(name + "  ");
            }
            Console.WriteLine();
        }
        public static void CreateAndPopulateList(ref List<string> l)
        {
            l = new List<string>();
            for(int i=0;i<10;i++)
            {
                l.Add("Name" + (i+1));
            }
        }
    }
}
