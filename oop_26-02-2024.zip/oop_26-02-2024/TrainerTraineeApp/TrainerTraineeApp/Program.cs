﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainerTraineeApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Training training = new Training();
            Trainer trainer = new Trainer();
            training.Trainer = trainer;
            trainer.Trainings.Add(training);
            Organization org = new Organization();
            org.Name = "Pratian Technologies";
            trainer.Org = org;
            Console.WriteLine($"org name : {training.GetTrainingOrgName()}");

            Trainee t1 = new Trainee();
            Trainee t2 = new Trainee();
            Trainee t3 = new Trainee();
            Trainee t4 = new Trainee();
            Trainee t5 = new Trainee();
            
            

            training.Trainees.Add( t1 );
            training.Trainees.Add( t2 );
            training.Trainees.Add( t3 );
            training.Trainees.Add( t4 );
            training.Trainees.Add ( t5 );

            trainer.Trainees.Add(t1);
            trainer.Trainees.Add(t2);
            trainer.Trainees.Add(t3);
            trainer.Trainees.Add(t4);
            trainer.Trainees.Add(t5);

            Console.WriteLine($"enter number of trainees count {training.GetNumOfTrainees()} ");

            Course course = new Course();
            Module m1 = new Module();
            Module m2 = new Module();

            course.Modules.Add( m1 );
            course.Modules.Add( m2 );
            training.TheCourse = course;


            Unit u1 = new Unit { Duration = 10};
            Unit u2 = new Unit { Duration = 60};
            Unit u3 = new Unit { Duration = 30};
            Unit u4 = new Unit { Duration = 20};

            m1.Units.Add( u1 );
            m1.Units.Add ( u2 );

            m2.Units.Add( u3 );
            m2.Units.Add ( u4 );


            Console.WriteLine($"enter duration {training.GetTrainingDurationInHours()}");

        }
    }
    class Organization
    {
        //private string name;
        public string Name { get; set; }
        public string getName() { return Name; }

    }
    class Trainer
    {
        public Organization Org { get; set; }
        public List<Trainee> Trainees { get; set; } = new List<Trainee>();
        public List<Training> Trainings { get; set; } = new List<Training>();

    }
    class Trainee
    {
        public Trainer TheTrainer { get; set; }
        public List<Training> Trainings { get; set; } = new List<Training>();
    }
    class Training
    {
        public Trainer Trainer { get; set; }
        public List<Trainee> Trainees { get; set; } = new List<Trainee>();
        public Course TheCourse { get; set; }
        public int GetNumOfTrainees() {
            //throw new System.NotImplementedException();
            return Trainees.Count;
        }
        public string GetTrainingOrgName() { return Trainer.Org.Name; }
        public int GetTrainingDurationInHours()
        {
            int totalDuration = 0;
            // for each Module in course
            foreach(Module m in TheCourse.Modules)
            {
                // for each unit in a module
                foreach(Unit unit in m.Units)
                {
                    totalDuration += unit.Duration;
                }
            }
            return totalDuration;
        }
    }
    class Course
    {
        public List<Training> Trainings { get; set; } = new List<Training>();
        public List<Module> Modules { get; set; } = new List<Module>();
    }
    class Module
    {
        public List<Unit> Units { get; set; } = new List<Unit>();
    }
    class Unit
    {
        public int Duration { get; set; }
        public List<Topic> Topics { get; set; } = new List<Topic>();
    }
    class Topic
    {
        public string Name { get; set; }

    }

}
