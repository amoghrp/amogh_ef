﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Company_Orders_Demo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Company c = new Company();

            Item i1 = new Item();
            i1.Discription = "item1";
            i1.Rate = 10;
            Item i2 = new Item();
            i2.Discription = "item2";
            i2.Rate = 20;
            Item i3 = new Item();
            i3.Discription = "item3";
            i3.Rate = 30;
            Item i4 = new Item();
            i4.Discription = "item4";
            i4.Rate = 40;

            Customer c1 = new Customer();
            Customer c2 = new Customer();
            RegCustomer c3 = new RegCustomer();
            c3.SpecialDiscountPercentage = 10;
            RegCustomer c4 = new RegCustomer();
            c4.SpecialDiscountPercentage = 10;

            Order o1 = new Order();
            Order o2 = new Order();
            Order o3 = new Order();
            Order o4 = new Order();

            o1.Customer = c1;
            o2.Customer = c2;
            o3.Customer = c3;
            o4.Customer = c4;

            OrderedItem oi1 = new OrderedItem();
            oi1.Quantity = 2;
            oi1.ItemInOrderedItem = i1;
            OrderedItem oi2 = new OrderedItem();
            oi2.Quantity = 2;
            oi2.ItemInOrderedItem = i2;
            OrderedItem oi3 = new OrderedItem();
            oi3.Quantity = 2;
            oi3.ItemInOrderedItem = i3;
            OrderedItem oi4 = new OrderedItem();
            oi4.Quantity = 2;
            oi4.ItemInOrderedItem = i4;


            
            o1.OrderedItemsInOrder.Add(oi1);
            o2.OrderedItemsInOrder.Add(oi2);
            o3.OrderedItemsInOrder.Add(oi3);
            o4.OrderedItemsInOrder.Add(oi4);
 
            c1.OrdersInCustomer.Add(o1);
            c2.OrdersInCustomer.Add(o2);
            c3.OrdersInCustomer.Add(o3);
            c4.OrdersInCustomer.Add(o4);

            c.ItemsInCompany.Add(i1);
            c.ItemsInCompany.Add(i2);
            c.ItemsInCompany.Add(i3);
            c.ItemsInCompany.Add(i4);

            c.CustomersInCompany.Add(c1);
            c.CustomersInCompany.Add(c2);
            c.CustomersInCompany.Add(c3);
            c.CustomersInCompany.Add(c4);

            Console.WriteLine(c.GetTotalWorthOfOrdersPlaced());

        }
    }

    public class Company
    {
        public List<Item> ItemsInCompany = new List<Item>();
        public List<Customer> CustomersInCompany = new List<Customer>();
        public double GetTotalWorthOfOrdersPlaced()
        {
            // implementatioin needed
            double totalworth = 0;

            foreach (Customer c in CustomersInCompany)
            {

                if ( c is RegCustomer )
                 {
                     RegCustomer regCustomer = (RegCustomer)c;
                     foreach (Order order in regCustomer.OrdersInCustomer)
                     {
                         foreach (OrderedItem ordereditem in order.OrderedItemsInOrder)
                         {
                             totalworth += ordereditem.Quantity * ordereditem.ItemInOrderedItem.Rate;
                         }
                     }
                     totalworth -= regCustomer.GetSpecialDiscount();

                 }
                 else
                 {

                foreach (Order order in c.OrdersInCustomer)
                {
                    
                    foreach (OrderedItem ordereditem in order.OrderedItemsInOrder)
                    {
                        totalworth += ordereditem.Quantity * ordereditem.ItemInOrderedItem.Rate;
                    }
                }
            }
            }
            return totalworth;
        }
    }
    public class Item
    {
        public String Discription { get; set; }
        public double Rate { get; set; }
    }
    public class Customer
    {
        public List<Order> OrdersInCustomer = new List<Order>();
    }
    public class RegCustomer : Customer
    {
        public double SpecialDiscountPercentage { get; set; }
        public double GetSpecialDiscount() {
            double sum = 0;
            foreach (Order order in OrdersInCustomer)
            {
                foreach(OrderedItem ordereditem in order.OrderedItemsInOrder)
                {
                    sum += ordereditem.Quantity * ordereditem.ItemInOrderedItem.Rate;
                }
            }
            return (sum * (SpecialDiscountPercentage / 100) );
        }
    }
    public class Order
    {
        public Customer Customer { get; set; }
        public List<OrderedItem> OrderedItemsInOrder = new List<OrderedItem>();

    }
    public class OrderedItem
    {
        public int Quantity { get; set; }
        public Item ItemInOrderedItem { get; set; }
    }

}
