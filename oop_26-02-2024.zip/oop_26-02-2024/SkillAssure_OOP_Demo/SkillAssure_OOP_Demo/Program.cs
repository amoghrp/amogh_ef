﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SkillAssure_OOP_Demo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MCQQuestion mq1 = new MCQQuestion();
            mq1.Marks = 1;
            MCQQuestion mq2 = new MCQQuestion();
            mq2.Marks = 1;
            MCQQuestion mq3 = new MCQQuestion();
            mq3.Marks = 1;
            MCQQuestion mq4 = new MCQQuestion();
            mq4.Marks = 1;
            MCQQuestion mq5 = new MCQQuestion();
            mq5.Marks = 1;
            MCQQuestion mq6 = new MCQQuestion();
            mq6.Marks = 1;


            HandsOnQuestion hq1 = new HandsOnQuestion();
            hq1.Marks = 5;
            HandsOnQuestion hq2 = new HandsOnQuestion();
            hq2.Marks = 5;
            HandsOnQuestion hq3 = new HandsOnQuestion();
            hq3.Marks = 5;
            HandsOnQuestion hq4 = new HandsOnQuestion();
            hq4.Marks = 5;
            HandsOnQuestion hq5 = new HandsOnQuestion();
            hq5.Marks = 5;
            HandsOnQuestion hq6 = new HandsOnQuestion();
            hq6.Marks = 5;

            Assessment a1 = new Assessment();
            a1.Questions.Add(mq1);
            Assessment a2 = new Assessment();
            a2.Questions.Add(mq2);
            Assessment a3 = new Assessment();
            a3.Questions.Add(mq3);
            Assessment a4 = new Assessment();
            a4.Questions.Add(mq4);
            Assessment a5 = new Assessment();
            a5.Questions.Add(mq5);
            Assessment a6 = new Assessment();
            a6.Questions.Add(mq6);
            Assessment a7 = new Assessment();
            a7.Questions.Add(hq1);
            Assessment a8 = new Assessment();
            a8.Questions.Add(hq2);
            Assessment a9 = new Assessment();
            a9.Questions.Add(hq3);
            Assessment a10 = new Assessment();
            a10.Questions.Add(hq4);
            Assessment a11 = new Assessment();
            a11.Questions.Add(hq5);
            Assessment a12 = new Assessment();
            a12.Questions.Add(hq6);
            Course course = new Course();
            course.AssessmentListCrs.Add(a1);
            course.AssessmentListCrs.Add(a7);
            course.AssessmentListCrs.Add(a8);

            Iteration i1 = new Iteration();
            i1.AssessmentsListItr.Add(a2);
            i1.AssessmentsListItr.Add(a3);
            i1.AssessmentsListItr.Add(a9);

            Iteration i2 = new Iteration();
            i2.AssessmentsListItr.Add(a4);
            i2.AssessmentsListItr.Add(a5);
            i2.AssessmentsListItr.Add(a10);
            i2.c = course;

            Iteration i3 = new Iteration();
            i3.AssessmentsListItr.Add(a6);
            i3.AssessmentsListItr.Add(a11);
            i3.AssessmentsListItr.Add(a12);


            SkillAssureTrainingModel satm = new SkillAssureTrainingModel();
            satm.IterationsList.Add(i1);
            satm.IterationsList.Add(i2);
            satm.IterationsList.Add(i3);


            Console.WriteLine($"total assessments {satm.GetTotalAssessmentsInTraining()} ");
            Console.WriteLine($"no of mcq {satm.GetNumMCQBasedAssessments()}");
            Console.WriteLine($" no of hands on {satm.GetNumHandsOnBasedAssessments()} ");
            Console.WriteLine($"total score of all assessments {satm.GetTotalScoreOfAllAssessments()} ");

        }
    }
    public class SkillAssureTrainingModel
    {
        public List<Iteration> IterationsList = new List<Iteration>();
        public string ClientName { get; set; }
        public int GetTotalAssessmentsInTraining() {
            int total_assessments = 0;
            foreach(Iteration itr in IterationsList)
            {
                total_assessments += itr.AssessmentsListItr.Count;
                Course c = itr.c;
                total_assessments += c.AssessmentListCrs.Count;

            }
            return total_assessments;
        }
        public int GetNumMCQBasedAssessments()
        {
            int mcqbased_assessments = 0;
            foreach(Iteration itr in IterationsList)
            {
                foreach(Assessment ass in itr.AssessmentsListItr)
                {
                    foreach(Question q in ass.Questions)
                    {
                        if(q is MCQQuestion)
                        {
                            mcqbased_assessments++;
                        }
                    }
                }
                foreach(Assessment ass in itr.c.AssessmentListCrs)
                {
                    foreach(Question q in ass.Questions)
                    {
                        if(q is MCQQuestion)
                        {
                            mcqbased_assessments++ ;
                        }
                    }
                }
            }
            return mcqbased_assessments;
            
        }
        public int GetNumHandsOnBasedAssessments()
        {

            int honbased_assessments = 0;
            foreach (Iteration itr in IterationsList)
            {
                foreach (Assessment ass in itr.AssessmentsListItr)
                {
                    foreach (Question q in ass.Questions)
                    {
                        if (q is HandsOnQuestion)
                        {
                            honbased_assessments++;
                        }
                    }
                }
                foreach (Assessment ass in itr.c.AssessmentListCrs)
                {
                    foreach (Question q in ass.Questions)
                    {
                        if (q is HandsOnQuestion)
                        {
                            honbased_assessments++;
                        }
                    }
                }
            }
            return honbased_assessments;
        }
        public int GetTotalScoreOfAllAssessments()
        {

            int total_score = 0;
            foreach(Iteration itr in IterationsList)
            {
                foreach(Assessment ass in itr.AssessmentsListItr)
                {
                    total_score += ass.GetTotalMarks();
                }
                foreach(Assessment ass in itr.c.AssessmentListCrs)
                {
                    total_score += ass.GetTotalMarks();
                }
            }
            return total_score;

        }
    }
    public class Iteration
    {
        public List<Assessment> AssessmentsListItr = new List<Assessment>();
        public Course c = new Course();
        public int IterationNo { get; set; }
        public string Goal { get; set; }

    }
    public class Course
    {
        public List<Assessment> AssessmentListCrs = new List<Assessment>();
        public string courseId { get; set; }
        public string Name { get; set; }
    }
    public class Assessment
    {
        public List<Question> Questions = new List<Question>();
        public string AssessmentId { get; set; }
        public string Desc { get; set; }
        public int NoQuestions { get; set; }
        public DateTime AssessmentDate { get; set; }
        public int GetTotalMarks()
        {
            int total_marks = 0;
            
            foreach(Question question in Questions)
            {

                total_marks += question.Marks;
            }
            return total_marks; 
        }

    }
    public abstract class Question
    {
        public abstract int Marks { get; set; }
    }
    public class MCQQuestion : Question
    {
        public override int Marks { get; set; }
        public string QuestionName { get; set; }
        public string Option1 { get; set; }
        public string Option2 { get; set; }
        public string Option3 { get; set; }
        public string Option4 { get; set; }
        public string RightOption { get; set; }
    }  
    public class HandsOnQuestion : Question
    {
        public override int Marks { get; set; }
        public string QuestionDesc { get; set; }
        public string ReferenceDocument { get; set; }

    }
    
}
