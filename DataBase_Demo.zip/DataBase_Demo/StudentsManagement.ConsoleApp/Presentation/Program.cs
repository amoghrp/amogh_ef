﻿using StudentsManagement.ConsoleApp.DataLayer;
using StudentsManagement.ConsoleApp.Entities_Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentsManagement.ConsoleApp
{
    internal class Program
    {
        private static IStudentsRepo studentDBRepository = StudentDBRepository.Instance;
        static void Main(string[] args)
        {

            Console.WriteLine("Student Database Manager");
            while (true)
            {
                

                Console.WriteLine("===========================================================");
                Console.WriteLine("1. Create Student Record ");
                Console.WriteLine("2. Get all Students Records ");
                Console.WriteLine("3. Get Student by RollNO");
                Console.WriteLine("4. Get Student/Students by other Parameters");
                Console.WriteLine("5. Edit Student Record");
                Console.WriteLine("6. Delete Student");
                Console.WriteLine("7. exit");
                Console.WriteLine("============================================================");
                Console.WriteLine("enter your choice [1-7] ");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1: Create_Student_Record(); break;
                    case 2: Get_all_Students_Records();break;
                    case 3: Get_Student_By_RollNo();break;
                    case 4: Edit_Student_Record();break;
                    case 5: Delete_Student();break;
                    case 6: Environment.Exit(0); break;
                    default: Console.WriteLine("invalid choice ..!!!");break;

                }
            }

        }

        private static void Create_Student_Record()
        {

            // collect student data from user and store into database -> PBI(product backlog information)
            Console.WriteLine("Enter New Student Details");
            Student student = new Student();
            Console.WriteLine("Enter First Name");
            student.FirstName = Console.ReadLine();
            Console.WriteLine("Enter Last Name");
            student.LastName = Console.ReadLine();
            Console.WriteLine("Please enter a date of birth in this format -> (e.g., 'yyyy-MM-dd'): ");
            string userInputDate = Console.ReadLine();

            DateTime userDate;

            
            if (DateTime.TryParse(userInputDate, out userDate))
            {
                student.DOB = userDate;
                
            }
            else
            {
                Console.WriteLine("Invalid date format. Please enter a valid date.");
                return;
            }

            Console.WriteLine("Enter Email ID");
            student.Email = Console.ReadLine();
            Console.WriteLine("Enter Mobile No");
            student.Mobile = Console.ReadLine();
            Console.WriteLine("Enter Course");
            student.Course = Console.ReadLine();
            // now call the repository object 
            studentDBRepository.Create_Student_Record(student);
            Console.WriteLine("student record created successfully");

        }

        private static void Get_all_Students_Records()
        {
            List<Student> students_list = studentDBRepository.Get_all_Students_Records();
            if(students_list == null)
            {
                Console.WriteLine("no records exits");
            }
            else
            {
                Console.WriteLine("showing all students \n===============");
                foreach (Student s in students_list)
                {
                    Print_Student(s);
                }
                Console.WriteLine("===================");
            }
        }

        private static void Print_Student(Student s)
        {
            Console.WriteLine($"\t{s.RollNo}\t{s.FirstName}\t{s.LastName}\t{s.DOB}\t{s.Email}\t{s.Mobile}\t{s.Course}");
        }

        private static void Get_Student_By_RollNo()
        {
            Console.WriteLine("enter roll no : ");
            int rno = int.Parse(Console.ReadLine());
            Student s = studentDBRepository.Get_Student_By_RollNo(rno);
            if(s== null)
            {
                Console.WriteLine("this student doesn't exist ");
            }
            else
            {
                Print_Student(s);
            }
        }

        

        private static void Edit_Student_Record()
        {
            Console.WriteLine("Enter Roll No");
            int rollNo = int.Parse(Console.ReadLine());
            Student student = studentDBRepository.Get_Student_By_RollNo(rollNo);


            if(student== null) 
            { 
                Console.WriteLine("Given student does not exist can't edit"); 
                return; 
            }
            else
            {
                //Console.WriteLine("Enter new Student Details");


                Console.WriteLine("Enter New Student Details");
                
                Console.WriteLine("Enter First Name");
                student.FirstName = Console.ReadLine();
                Console.WriteLine("Enter Last Name");
                student.LastName = Console.ReadLine();
                Console.WriteLine("Please enter a date of birth in this format -> (e.g., 'yyyy-MM-dd'): ");
                string userInputDate = Console.ReadLine();

                DateTime userDate;

                if (DateTime.TryParse(userInputDate, out userDate))
                {
                    student.DOB = userDate;

                }
                else
                {
                    Console.WriteLine("Invalid date format. Please enter a valid date.");
                    return;
                }

                Console.WriteLine("Enter Email ID");
                student.Email = Console.ReadLine();
                Console.WriteLine("Enter Mobile No");
                student.Mobile = Console.ReadLine();
                Console.WriteLine("Enter Course");
                student.Course = Console.ReadLine();
                // now call the repository object for editing
                if(studentDBRepository.Edit_Student_Record(rollNo, student))
                    Console.WriteLine("student record edited successfully");

            }
        }
        private static void Delete_Student()
        {
            Console.WriteLine("Enter Roll No");
            int rollNo = Convert.ToInt32(Console.ReadLine());
            
            Student s = studentDBRepository.Get_Student_By_RollNo(rollNo);
            if(s == null) 
            {
                Console.WriteLine("Given Roll No Doesn't Exists Can't Delete");
            }
            else
            {
                if(studentDBRepository.Delete_Student(rollNo)) 
                {
                    Console.WriteLine("Deletion Success");
                }
            }
        }

    }
}
