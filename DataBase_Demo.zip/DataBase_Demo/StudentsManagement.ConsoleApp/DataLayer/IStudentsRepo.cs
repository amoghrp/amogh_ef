﻿using StudentsManagement.ConsoleApp.Entities_Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentsManagement.ConsoleApp.DataLayer
{
    public interface IStudentsRepo
    {
        void Create_Student_Record(Student s);
        List<Student> Get_all_Students_Records();
        Student Get_Student_By_RollNo(int roll_no);
        
        bool Edit_Student_Record(int rno,Student newStudent);

        bool Delete_Student(int rno);

    }

}
