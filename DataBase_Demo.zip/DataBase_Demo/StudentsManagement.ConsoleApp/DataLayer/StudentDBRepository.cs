﻿using StudentsManagement.ConsoleApp.Entities_Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentsManagement.ConsoleApp.DataLayer
{
    public class StudentDBRepository : IStudentsRepo
    {
        private static string MyConnection_String = @"Server=(localdb)\mssqllocaldb;Database=StudentDB2024;Integrated Security=true";
        private StudentDBRepository() { }

        public static readonly StudentDBRepository Instance = new StudentDBRepository();
        public void Create_Student_Record(Student student)
        {
            SqlConnection conn = new SqlConnection();
            try
            {
                
                conn.ConnectionString = MyConnection_String;
                conn.Open();

                string sqlInsert = $"insert into students values('{student.FirstName}','{student.LastName}','{student.DOB}','{student.Email}','{student.Mobile}','{student.Course}')";
                SqlCommand cmd = new SqlCommand(sqlInsert, conn);

                cmd.ExecuteNonQuery();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            
        }

        public bool Delete_Student(int rno)
        {
            SqlConnection conn = new SqlConnection();
            try
            {
                conn.ConnectionString = MyConnection_String;
                conn.Open();
                //string sqlDelete = "DELETE FROM students WHERE Roll_No = @RollNo";
                string sqlDelete = $"delete from students where Roll_No = '{rno}'";
                SqlCommand cmd = new SqlCommand(sqlDelete,conn);
                cmd.ExecuteNonQuery();
            }
            catch(Exception ex)
            {
                
                Console.WriteLine(ex.Message);
                return false;
            }
            finally
            {
                conn.Close ();
            }
            return true;
        }

        public bool Edit_Student_Record(int rno, Student newStudent)
        {
            
            try
            {
                using (SqlConnection conn = new SqlConnection())
                {
                    conn.ConnectionString=MyConnection_String;
                    conn.Open();
                    string sqlEdit = $"update students set FirstName = '{newStudent.FirstName}', LastName = '{newStudent.LastName}', DOB = '{newStudent.DOB}', Email = '{newStudent.Email}', Mobile = '{newStudent.Mobile}', Course = '{newStudent.Course}' WHERE Roll_No = {newStudent.RollNo};";
                    using(SqlCommand cmd = new SqlCommand(sqlEdit,conn))
                    {
                        if(cmd.ExecuteNonQuery()>0)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
            //return true;
        }

        public List<Student> Get_all_Students_Records()
        {
            List<Student> students_list = new List<Student>();
            try
            {
                using (SqlConnection conn = new SqlConnection())
                {
                    conn.ConnectionString=MyConnection_String;
                    conn.Open();
                    string sqlQuery = "select * from students";
                    using(SqlCommand cmd = new SqlCommand( sqlQuery,conn))
                    {
                        using(SqlDataReader reader = cmd.ExecuteReader())
                        {
                            
                            if (!reader.HasRows)
                            {
                                // No rows returned, return null
                                return null;
                            }
                            while (reader.Read())
                            {
                                
                                Student s = new Student();
                                s.RollNo = Convert.ToInt32(reader["Roll_No"]);
                                s.FirstName = reader["FirstName"].ToString();
                                s.LastName = reader["LastName"].ToString();
                                s.DOB = (DateTime)reader["DOB"];
                                s.Email = reader["Email"].ToString();
                                s.Mobile = reader["Mobile"].ToString();
                                s.Course = reader["Course"].ToString();
                                students_list.Add(s);
                            }
                            conn.Close();
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
            return students_list;

        }

        public Student Get_Student_By_RollNo(int roll_no)
        {

            Student student = new Student();
            try
            {
                using (SqlConnection conn = new SqlConnection())
                {
                    conn.ConnectionString = MyConnection_String;
                    conn.Open();
                    
                    string sqlQuery = "select * from students where roll_no = @Roll_No";

                    using(SqlCommand cmd = new SqlCommand(sqlQuery,conn))
                    {
                        // Add parameters to prevent SQL injection 
                        cmd.Parameters.AddWithValue("@Roll_No", roll_no);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if(reader.Read()) // if data exists
                            {
                                student.RollNo = Convert.ToInt32(reader["Roll_No"].ToString());
                                student.FirstName = reader["FirstName"].ToString();
                                student.LastName = reader["LastName"].ToString();
                                student.DOB = (DateTime)reader["DOB"];
                                student.Email = reader["Email"].ToString();
                                student.Mobile = reader["Mobile"].ToString() ;
                                student.Course = reader["Course"].ToString();
                                //return student;
                                
                            }
                            else
                            {
                                return null;
                            }
                        }
                    }

                }

            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }

            return student;


        }

    }
}

//Console.WriteLine("no of rows affected  = "+x);
/*

// The System.Data will have all the ADO Connection related classes
--- SqlConnection conn = new SqlConnection();
//  now we have to give connection string as follows 
server name , DataBase , Credentials( only if given then only we have to give userid and password )
conn.ConnectionString = @"Server=(localdb)\mssqllocaldb;Database=StudentDB2024;Integrated Security=true"; 
// step 1 : Connect to DB

conn.Open();
Console.WriteLine("Connected....");

// Step 2 : Send Sql command to DB
string sqlInsert = $"insert into students values('{student.FirstName}','{student.LastName}','{student.DOB}','{student.Email}','{student.Mobile}','{student.Course}')";

SqlCommand cmd = new SqlCommand(sqlInsert,conn); //like this or like given below 
//cmd.Connection = conn;
//cmd.CommandText = sqlInsert;

int x = cmd.ExecuteNonQuery();

// Step 3 : (If Required ) Process the returned data ( optional step )
Console.WriteLine("no of rows affected  = "+x);

// Step 4 : Close db Connection
conn.Close();
// DB Server : SQL Server
// DataBase : StudentsDB2024
// Table : Students
// Frameworks Used : ADO.NET
// Approach : Connected Approach (first) -> later we will go for disconnected approach

Console.WriteLine("saved...");




*/