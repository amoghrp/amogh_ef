﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Company_Lab_27_02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Company cp = new Company();
            cp.Name = "Mycompany";
            Employee e1 = new Employee();
            e1.Name = "amogh";
            Employee e2 = new Employee();
            e2.Name = "parth";
            Employee e3 = new Employee();
            e3.Name = "emp3";
            Employee e4 = new Employee();
            e4.Name = "emp4";

            Customer c1 = new Customer();
            Customer c2 = new Customer();
            cp.CustomersList.Add(c1);
            cp.CustomersList.Add(c2);



            e1.EmpId = 1;
            e1.Basic = 100;
            e1.Experience = 2;

            e2.EmpId = 2;
            e2.Basic = 200;
            e2.Experience = 3;

            e3.EmpId = 3;
            e3.Basic = 400;
            e3.Experience = 5;

            e4.EmpId = 4;
            e4.Basic = 600;
            e4.Experience = 7;


            cp.EmployeesList.Add(e1);
            cp.EmployeesList.Add(e2);
            cp.EmployeesList.Add(e3);
            cp.EmployeesList.Add(e4);
            
            Console.WriteLine("enter id of employee to know he exists or not ");
            int eid = Convert.ToInt32(Console.ReadLine());
            if(cp.GetEmployee(eid) != null)
            {
                Console.WriteLine($"employee is {cp.GetEmployee(eid).Name}");
            }
            else
            {
                Console.WriteLine("employee not found");
            }
            Console.WriteLine($"total salary payout = {cp.GetTotalSalaryPayout()}");
            Console.WriteLine($"total no of customers = {cp.GetTotalCustomers()}");
            Console.WriteLine($"total no of employees = {cp.GetTotalEmployees()}");


        }
        public class Company
        {
            public string Name { get; set; }
            public DateTime IncorporatedDt { get; set; }

            public List<Customer> CustomersList { get; set; } = new List<Customer>();
            public List<Employee> EmployeesList { get; set; } = new List<Employee>();
            public List<Branch> BranchesList { get; set; }= new List<Branch>();
            public Branch corp { get; set; }
            public Branch reg { get; set; }

            public Employee GetEmployee(int empid)
            {
                foreach (Employee emp in EmployeesList)
                {
                    if(emp.EmpId == empid)
                    {
                        return emp;
                    }
                }
                return null;
            }
            public double GetTotalSalaryPayout()
            {
                double total_sal = 0;
                foreach(Employee emp in EmployeesList)
                {
                    total_sal += emp.GetSalary();
                }
                return total_sal;
            }
            public int GetTotalCustomers()
            {
                return CustomersList.Count;
            }
            public int GetTotalEmployees()
            {
                return EmployeesList.Count;
            }

        }
        public class Branch
        {
            public string Name { get; set; }
        }
        public interface IHuman
        {
            string Name { get; set; }
            int Age { get; set; }
            string Address { get; set; }
        }
        public abstract class Person : IHuman
        {
            public string Name { get; set; }
            public int Age { get; set; }
            public string Address { get; set; }

        }
        public class Employee : Person
        {
            public int EmpId { get; set; }
            public double Basic {  get; set; }
            public double Experience { get; set; }
            public double GetSalary()
            {

                return SalaryCalculator.CalculateSalary(Experience,Basic);
            }

        }
        public class Customer : Person
        {
            public int CustomerId { get; set; }
            public string Email { get; set; }

        }
        public class SalaryCalculator
        {
           
            public static double CalculateSalary(double experience, double basic)
            {
                double salary;
                if ( experience <= 2)
                {
                    salary = basic + basic * (0.3);
                }
                else if (experience <= 4)
                {
                    salary = basic + basic * (0.4);
                }
                else if (experience <= 6)
                {
                    salary = basic + basic * (0.5);
                }
                else
                {
                    salary = basic + basic * (0.65);
                }

                return salary;
            }
            
        }
    }
}
