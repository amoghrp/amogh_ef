﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPExercise_outstanding_27_02_24
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Person p1 = new Student("def",84);
            Person p2 = new Student("abc",89);

            Person p3 = new Professor("pf1",4);
            Person p4 = new Professor("pf2",5);
            Person p5 = new Professor("pf3",6);
            List<Person> PersonsList = new List<Person>();  
            PersonsList.Add(p1);
            PersonsList.Add(p2);
            PersonsList.Add(p3);
            PersonsList.Add(p4);
            PersonsList.Add(p5);

            foreach (Person person in PersonsList)
            {
                if (person != null && (person.IsOutStanding()))
                {
                    if(person is  Student)
                    {
                        Console.WriteLine($"student details name = {person.Name}     Percentage = {((Student)person).Percentage}");

                    }
                    else
                    {
                        Console.WriteLine($"professor details name = {person.Name}    No of books published = {((Professor)person).BooksPublished}");
                    }
                }
            }


            
        }
        public abstract class Person
        {
            public Person(string Name)
            {
                this.Name = Name;
            }
            public Person() { }
            public string Name { get; set; }
            public string GetName() { return Name; }
            public void SetName(string name) { Name = name;}
            public abstract bool IsOutStanding();
        }
        public class Professor : Person
        {
            public int BooksPublished { get; set; }
            public Professor() { }
            public Professor(string Name,int booksPublished):base(Name)
            {
                BooksPublished = booksPublished;
            }
            public void Print() {
                Console.WriteLine($"name = {Name}, books published = {BooksPublished}");
            }
            public override bool IsOutStanding() 
            {
                if (BooksPublished > 4) return true ;
                return false;
            }

        }
        public class Student : Person
        {
            public double Percentage { get; set; }
            public Student() { }
            public Student(string Name ,double percentage):base(Name) 
            {
                Percentage = percentage;
            }
            public void Display() 
            {
                Console.WriteLine($"name of student = {Name} , percentage= {Percentage}");
            }
            public override bool IsOutStanding()
            {
                if(Percentage > 85)
                {
                    return true ;
                }
                return false;
            }
        }
    }
}