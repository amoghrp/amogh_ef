﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace OOPExercise_27_02_2024
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Rectangle r = new Rectangle();
            Triangle t = new Triangle();
            Circle c = new Circle();
            c.Name = "circle";
            t.Name = "Triangle";
            r.Name = "Rectangle";

            c.Radius = 23; 
            c.CalculateArea();

            t.A = 3;
            t.B = 4;
            t.C = 5;
            t.CalculateArea();

            r.A = 6;
            r.B = 7;
            r.CalculateArea();
            Console.WriteLine($"area of circle = {c.Area} \n area of triangle = {t.Area} \n area of Rectangle = {r.Area}");


        }
        public interface IShape
        {
            string Name { get; set; }
            double Area { get; set; }
            void CalculateArea();
        }
        public class Circle : IShape
        {
            public string Name { get; set; }
            public double Area { get; set; }
            public double Radius { get; set; }
            public void CalculateArea()
            {
                Area = Math.PI * Radius * Radius;
            }
        }
        public class Triangle :IShape
        {
            public string Name { get; set; }
            public double Area { get; set; }
            public double A {  get; set; }
            public double B { get; set; }
            public double C { get; set; }
            public double S { get; set; }

            public void CalculateArea()
            {
                S = ( A + B + C )/ 2;
                Area = Math.Sqrt( S* (S-A) *(S-B)*(S-C) );
            }
            
        }
        public class Rectangle : IShape
        {
            public string Name { get; set; }
            public double Area { get; set; }
            public double A { get; set; }
            public double B { get; set; }
            public void CalculateArea()
            {
                Area = A * B;
            }
        }
    }
}
