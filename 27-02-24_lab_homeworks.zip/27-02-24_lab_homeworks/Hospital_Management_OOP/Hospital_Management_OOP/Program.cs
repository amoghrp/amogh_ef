﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Hospital_Management_OOP.Program;

namespace Hospital_Management_OOP
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Hospital h = new Hospital();
            Patient p1 = new Patient();
            Patient p2 = new Patient();
            Patient p3 = new Patient();
            Patient p4 = new Patient();
            Patient p5 = new Patient();
            Patient p6 = new Patient();
            Patient p7 = new Patient();
            Patient p8 = new Patient();
            
            Employee e1= new Employee();
            Employee e2= new Employee();
            ConsultantDoctor e3= new ConsultantDoctor();
            e3.Speciality = "abc";
            ConsultantDoctor e4 = new ConsultantDoctor();
            e4.Speciality = "def";
            Doctor e5= new Doctor();
            e5.Speciality = "abc";
            Doctor e6= new Doctor();
            e6.Speciality = "def";

            h.EmployeesList.Add(e1);
            h.EmployeesList.Add(e2);
            h.EmployeesList.Add(e3);
            h.EmployeesList.Add(e4);
            h.EmployeesList.Add(e5);
            h.EmployeesList.Add(e6);


            Ward w1 = new Ward();
            Ward w2 = new Ward();
            Ward w3 = new Ward();
            Ward w4 = new Ward();

            h.WardsList.Add(w1);
            h.WardsList.Add(w2);
            h.WardsList.Add(w3);
            h.WardsList.Add(w4);

            w1.WType = WardType.SurgicalUnit;
            w2.WType = WardType.GeneralUnit;
            w3.WType = WardType.PediatricUnit;
            w4.WType = WardType.IntensiveCareUnit;

            w1.PatientsList.Add(p1);
            w2.PatientsList.Add(p2);
            w3.PatientsList.Add(p3);
            w4.PatientsList.Add(p4);
            w1.PatientsList.Add(p5);
            w2.PatientsList.Add(p6);
            w3.PatientsList.Add(p7);
            w4.PatientsList.Add(p8);

            w1.BasicCost = 100;
            w2.BasicCost = 100;
            w3.BasicCost = 100;
            w4.BasicCost = 100;

            Console.WriteLine($"total patients = {h.GetTotalPatients()}");
            Console.WriteLine($"total patients in ward w1 = {h.GetTotalPatientsByWard(w1)}");

            Console.WriteLine($"total patients in ward w2 = {h.GetTotalPatientsByWard(w2)}");
            Console.WriteLine($"total doctors = {h.GetTotalDoctors()}");
            List<Doctor> specdocs = h.GetDoctorBySpecialization("abc");
            foreach( Doctor d in specdocs)
            {
                Console.WriteLine(d + "  specialized in " + d.Speciality);

            }
            Console.WriteLine("total consultants " + h.GetTotalConsultants() );
            Console.WriteLine("enter wardtype choices \n0 general \n1 pediatric \n2 intensive \n3 surgical ");
            int wt = Convert.ToInt32(Console.ReadLine());
            
            switch (wt)
            {
                case 0:
                    Console.WriteLine($"ward cost of type {WardType.GeneralUnit} is = {h.GetWardCostByType(WardType.GeneralUnit)}");
                    break;
                case 1:
                    Console.WriteLine($"ward cost of type {WardType.PediatricUnit} is = {h.GetWardCostByType(WardType.PediatricUnit)}");
                    break;
                case 2:
                    Console.WriteLine($"ward cost of type {WardType.IntensiveCareUnit} is = {h.GetWardCostByType(WardType.IntensiveCareUnit)}");
                    break;
                case 3:
                    Console.WriteLine($"ward cost of type {WardType.SurgicalUnit} is = {h.GetWardCostByType(WardType.SurgicalUnit)}");
                    break;
                default:
                    Console.WriteLine("wrong choice");
                    break;

            }



        }
        public class Hospital
        {
            public string Name { get; set; }
            public long Phone { get; set; }
            public string Address { get; set; }
            public List<Ward> WardsList { get; set; } = new List<Ward>();
            public List<Employee> EmployeesList { get; set; } = new List<Employee>();

            public int GetTotalPatients()
            {
                int totalPatients = 0;
                foreach(Ward w in WardsList)
                {
                    totalPatients += w.PatientsList.Count;
                }
                return totalPatients;
            }

            public int GetTotalPatientsByWard(Ward w)
            {
                return w.PatientsList.Count;
            }
            public int GetTotalDoctors()
            {
                int totalDoctors = 0;
                foreach(Employee emp in EmployeesList)
                {
                    if (emp is Doctor) totalDoctors++;
                }
                return totalDoctors;
            }

            public List<Doctor> GetDoctorBySpecialization(string specialization)
            {
                List<Doctor> docs = new List<Doctor>();
                foreach(Employee e in EmployeesList)
                {
                    if(e is Doctor )
                    {
                        Doctor d = (Doctor)e;

                        if(d.Speciality == specialization)
                        {
                            docs.Add(d);
                        }
                    }
                }
                return docs;
            }
            public int GetTotalConsultants()
            {
                int totalConsultants = 0;
                foreach(Employee e in EmployeesList)
                {
                    if(e is Doctor)
                    {
                        Doctor d = (Doctor)e;
                        if(d is ConsultantDoctor)
                        {
                            totalConsultants++;
                        }
                    }
                }
                return totalConsultants;
            }
            public double GetWardCostByType(WardType Wt)
            {
                double wcost = 0;
                foreach(Ward w in WardsList)
                {
                    if(w.WType == Wt)
                    {
                        //wcost += w.GetWardCost();
                        // or 
                        wcost += WardCostCalculator.FindWardCost(w.BasicCost,w.WType);
                    }
                }
                return wcost;
            }

        }
        public enum Gender
        {
            Male,
            Female,
            Other
        }
        public abstract class Person
        {
            public string Name { get; set; }
            public string Title { get; set; }
            public DateTime Date { get; set; }
            public string ResidentialAddress { get; set; }
            public Gender gender { get; set; }
            public string Phone { get; set; }

        }
        public class Patient : Person
        {
            public DateTime AdmittedDate { get; set; }
            public List<string> Allergies { get; set; } = new List<string>();
            public string PatientName { get; set; }
            public int Age { get; set; }
        }
        public class Employee : Person
        {
            public DateTime DateofJoin { get; set; }
            public string Education { get; set; }

        }
        public class Doctor : Employee
        {
            public string Speciality { get; set; }
        }
        public class ConsultantDoctor : Doctor
        {

        }
        public class InternalDoctor : Doctor
        {

        }
        public class Receptionist : Employee
        {

        }
        public class Nurse : Employee
        {

        }

        public class Ward
        {
            public string WardName { get; set; }
            public WardType WType { get; set; }
            public double BasicCost { get; set; }

            public List<Patient> PatientsList { get; set; } = new List<Patient>();
            public double GetWardCost()
            {
                return WardCostCalculator.FindWardCost(BasicCost,WType);
            }
        }
        public enum WardType
        {
            IntensiveCareUnit,
            GeneralUnit,
            PediatricUnit,
            SurgicalUnit,

        }
        public class WardCostCalculator
        {
            public static double FindWardCost(double BasicCost,WardType WType)
            {
                if(WType == WardType.GeneralUnit)
                {
                    return BasicCost + BasicCost * (0.1);
                }
                else if(WType == WardType.IntensiveCareUnit)
                {
                    
                    return BasicCost + BasicCost * (0.2);
                }
                else if (WType == WardType.PediatricUnit)
                {
                    return (BasicCost + BasicCost * (0.25));
                }
                else
                {
                    return BasicCost + (BasicCost * (0.4));
                }
                return 0;
            }
        }
        
    }
}
