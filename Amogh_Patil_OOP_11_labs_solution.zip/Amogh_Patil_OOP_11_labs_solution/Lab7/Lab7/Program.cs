﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab7
{
    class Program
    {
        static void Main(string[] args)
        {
            int Marks1, Marks2, Marks3;

            //Accept the values from command line arguments
            Marks1 = CustomConsole.ReadInt();
            Marks2 = CustomConsole.ReadInt();
            Marks3 = CustomConsole.ReadInt();

            //Store the values entered in the object
            ResultFinder Finder = new ResultFinder();
            Finder.Marks1 = Marks1;
            Finder.Marks2 = Marks2;
            Finder.Marks3 = Marks3;


            //Display all the information with the help of get and other methods
            Console.WriteLine("Marks entered------------- ");

            Console.WriteLine("Marks 1 : "+Marks1 );
            Console.WriteLine("Marks 2 : "+Marks2 );
            Console.WriteLine("Marks 3 : "+Marks3 );
            int Total = Finder.GetTotal();
            Console.WriteLine("Total : "+Total );
            double avg = Finder.GetAverage();
            Console.WriteLine("Average : "+avg );
            string r = Finder.GetResult();
            Console.WriteLine("Result : "+r );

            Console.ReadLine();
        }
    }
}
