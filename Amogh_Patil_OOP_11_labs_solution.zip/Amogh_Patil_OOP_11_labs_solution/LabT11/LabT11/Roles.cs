﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LabT11
{


    /*public static int DEVELOPER { get { return 1; } }

    public static int TEST_ENGINEER { get { return 2; } }

    public static int SR_DEVELOPER { get { return 3; } }

    public static int DESIGNER { get { return 4; } }*/

    /*class Roles
    {
        public static int DEVELOPER { get { return 1; } }

        public static int TEST_ENGINEER { get { return 2; } }

        public static int SR_DEVELOPER { get { return 3; } }

        public static int DESIGNER { get { return 4; } }

       
    }*/
    public enum Roles{
        DEVELOPER =1,
        TEST_ENGINEER = 2,
        SR_DEVELOPER = 3,
        DESIGNER = 4
    }

    
}
