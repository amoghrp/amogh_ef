﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab3
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Employee Emp = new Employee();

            StoreData(Emp);

            ShowData(Emp);
        }

        static void StoreData(Employee Emp)
        {
            // we have to store id,name,gender,Address
            Console.WriteLine("enter the emp id");
            int id = CustomConsole.ReadInt();
            Emp.EmployeeId = id;

            Console.WriteLine("enter the name");
            string name = CustomConsole.ReadString();
            Emp.Name = name;

            Console.WriteLine("enter gender");
            char gender = CustomConsole.ReadChar();
            Emp.Gender = gender;

            Console.WriteLine("enter address details");
            Address ad = new Address();
            // add1 , add2, city, pincode
            Console.WriteLine("enter address 1");
            string add1 = CustomConsole.ReadString();  
            ad.Address1 = add1;
            

            Console.WriteLine("enter address 2");
            string add2 = CustomConsole.ReadString();
            ad.Address2 = add2;

            Console.WriteLine("enter city");
            string city = CustomConsole.ReadString();
            ad.City = city;

            Console.WriteLine("enter pincode");
            int pin = CustomConsole.ReadInt();
            ad.PinCode = pin;

            Emp.EmpAddress = ad;

        }

        static void ShowData(Employee Emp)
        {

            //----------------Display the employee information
            Console.WriteLine("Employee Id : "+Emp.EmployeeId);
            Console.WriteLine("Employee Name : "+Emp.Name);
            Console.WriteLine("Employee Gender : "+Emp.Gender);

            Console.WriteLine("Employee Address : --------------");
            Address ad = new Address();
            ad = Emp.EmpAddress;
            Console.WriteLine("Address 1 : "+ad.Address1);
            Console.WriteLine("Address 2 : "+ad.Address2);
            Console.WriteLine("City : "+ad.City);
            Console.WriteLine("PinCode : "+ad.PinCode);
            Console.WriteLine("----------------------------------");

            Console.ReadLine();
        }
    }
}
