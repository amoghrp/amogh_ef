﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab3
{
    /// <summary>
    /// Class to represent employee information
    /// </summary>
    class Employee
    {
        /// <summary>
        /// Properties of the class
        /// </summary>
        /// id,name,gender,Address
        private int id;
        public int EmployeeId {
            get { return id; }
            set { id = value; }
        }
        string name;
        public string Name {
            get { return name; }
            set { name = value; }
        }
        char gender;
        public char Gender {
            get { return gender; }
            set { gender = value; } 
        }

        Address ad = new Address();
        public Address EmpAddress {
            get { return ad; }
            set { ad = value; }
        }
    }
}
