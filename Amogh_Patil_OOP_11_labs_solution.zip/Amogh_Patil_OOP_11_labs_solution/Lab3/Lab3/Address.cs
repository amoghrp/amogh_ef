﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab3
{
    class Address
    {
        /// <summary>
        /// Properties of the class
        /// </summary>
        private string _address1, _address2, _city;
        private int _pinCode;
        public string Address1
        {
            get
            {
                return _address1;
            }

            set
            {
                _address1 = value;
            }
        }
        public string Address2 {
            get { 
            return _address2;
            }
            set
            {
                _address2 = value;
            }
        }
        public string City {
            get {  return _city; }   
            set {  _city = value; }
            
        }
        public int PinCode {
            get { return _pinCode; }
            set { _pinCode = value; }
        }
    }
}
