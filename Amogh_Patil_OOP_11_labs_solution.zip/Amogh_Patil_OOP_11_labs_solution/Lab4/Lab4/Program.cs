﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab4
{
    class Program
    {
        static void Main(string[] args)
        {
            int cache_value = CustomConsole.ReadInt();
            
            Cache ch = new Cache(cache_value);
            Console.WriteLine("MAX_CAPACITY is " + Cache.GetMaxCapacity());


            Console.WriteLine("MAX_CAPACITY is " + Cache.GetMaxCapacity());


            Console.WriteLine("MAX_CAPACITY is " + Cache.GetMaxCapacity());

            Console.ReadLine();
        }
    }
}
