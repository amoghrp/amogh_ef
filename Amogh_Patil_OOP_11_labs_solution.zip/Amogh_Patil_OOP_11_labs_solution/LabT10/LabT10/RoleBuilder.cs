﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LabT10
{
    class RoleBuilder
    {
        

        /// <summary>
        /// Method to get role description for a given role id
        /// </summary>
        /// <param name="RoleId"></param>
        /// <returns>Description of a role id</returns>
        public static string GetRoleDescription(int RoleId)
        {
            switch (RoleId)
            {
                case 1:
                    return " roleid 1 = DEVELOPER";

                case 2:
                    return "roleid 2 = TEST_ENGINEER";

                case 3:
                    return "roleid 3 = SR_DEVELOPER";
                case 4:
                    return "roleid 4 = DESIGNER";
                default:
                    return "UNDEFINED";

            }
        }
    }
}
