﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LabT10
{
    class SalaryCalculator
    {
        /// <summary>
        /// Method to calculate the salary of an employee
        /// </summary>
        /// <param name="emp"></param>
        /// <returns></returns>
        public static double GetSalary(Employee emp)
        {
            
                // Salary => Basic + HRA + Allowance
                return emp.Basic + emp.HRA + GetAllowance(emp);
            
        }

        /// <summary>
        /// Method to get the allowance for an employee based on the percentage
        /// </summary>
        /// <param name="emp"></param>
        /// <returns></returns>
        public static double GetAllowance(Employee emp)
        {
            return (emp.Basic * emp.AllowancePercentage) / 100;
        }
    }
}
